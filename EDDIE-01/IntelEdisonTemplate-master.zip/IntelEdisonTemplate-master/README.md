Intel Edison Mounting Board Template

More info on the Intel Edison:
https://communities.intel.com/servlet/JiveServlet/previewBody/23158-102-3-27299/edison-module_HG_331189-001.pdf

Intended for use with KiCAD
http://www.kicad-pcb.org/display/KICAD/KiCad+EDA+Software+Suite
- to install on Windows, use winbuilder:
https://launchpad.net/kicad-winbuilder

building KiCAD with Winbuilder takes like a day, but it's worth it. The older version of KiCAD available on the web site is lacking some very nice features that CERN implemented.

A footprint for the Hirose connector used by the Intel Edison doesn't come with any of the standard libraries of KiCAD. I made one in my own KiCAD library, available here:
https://github.com/mogar/KiCAD_libs
