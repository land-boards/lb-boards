#include "vos.h"
#include "devman.h"
#include "IOMUX.h"

#include "USBHost.h"
#include "msi.h"
#include "fat.h"
#include "gpio.h"
#include "sdcard.h"
#include "SD Card - Test App.h"
#include "SPIMaster.h"
#include "string.h"
#include "stdio.h"
/* Forward Declarations */
void firmware(void);
unsigned char IOMux_Setup();

vos_tcb_t *tcbFirmware;

//==============================================================================
// Application Functions
//==============================================================================
void main(void)
{
     // SPIMaster context structure
    spimaster_context_t spimasterCtx;
    // GPIO context
    gpio_context_t gpioCtx;

    /* call VOS initialisation routines */
    vos_init(50, VOS_TICK_INTERVAL, NUMBER_OF_DEVICES);
    vos_set_clock_frequency(VOS_48MHZ_CLOCK_FREQUENCY);

    //*********************************************************
    // INITIALISE DRIVERS
    //*********************************************************
    spimasterCtx.buffer_size = VOS_BUFFER_SIZE_512_BYTES;
    spimaster_init(VOS_DEV_SPIMASTER, &spimasterCtx);
    sd_init(VOS_DEV_SDCARD);
    fatdrv_init(VOS_DEV_FTFS);
    gpioCtx.port_identifier = GPIO_PORT_B;
    gpio_init(VOS_DEV_GPIO, &gpioCtx);

    /* create threads for firmware application (no parameters) */
    tcbFirmware = vos_create_thread(50, 8192, firmware, 0);

    /* Device IOMux Settings */
    IOMux_Setup();

    /* start VOS scheduler */
    vos_start_scheduler();

main_loop:
    goto main_loop;
}

unsigned char IOMux_Setup()
{
    unsigned char packageType = vos_get_package_type();

    if (packageType == VINCULUM_II_64_PIN)
    {
        // SPIMaster to V2EVAL board pins
        vos_iomux_define_output(19 ,IOMUX_OUT_SPI_MASTER_CLK);  // SCLK
        vos_iomux_define_output(20,IOMUX_OUT_SPI_MASTER_MOSI); // MOSI
        vos_iomux_define_input(22,IOMUX_IN_SPI_MASTER_MISO);   //MISO
        vos_iomux_define_output(23,IOMUX_OUT_SPI_MASTER_CS_0); // CS
        vos_iomux_define_input(16,IOMUX_IN_GPIO_PORT_B_1);   //Card Detect
        vos_iomux_define_input(15,IOMUX_IN_GPIO_PORT_B_0);   //Write Protect
    }

    return 0;
}

void firmware(void)
{
    unsigned char card_type;
    unsigned char *s = "Hello World!";

    VOS_HANDLE hSpiMaster, hSDCard, hFat, hGPIO;
    msi_ioctl_cb_t msi_cb;
    gpio_ioctl_cb_t gpio_iocb;
    sdcard_ioctl_cb_attach_t sd_cb;
    fatdrv_ioctl_cb_attach_t fat_cb;
    fat_ioctl_cb_t fat_iocb;

    // Handle for the file...
    FILE *file;

    // Open the device drivers...
    hGPIO = vos_dev_open(VOS_DEV_GPIO);
    hSpiMaster = vos_dev_open(VOS_DEV_SPIMASTER);
    hSDCard = vos_dev_open(VOS_DEV_SDCARD);
    hFat = vos_dev_open(VOS_DEV_FTFS);

    // Set the GPIO pins to input...
    gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_SET_MASK;
    gpio_iocb.value = 0x00;
    vos_dev_ioctl(hGPIO, &gpio_iocb);

    // Set-up the context for the SD Card driver....
    sd_cb.SPI_Handle = hSpiMaster;
    sd_cb.GPIO_Handle = hGPIO;
    sd_cb.WP_Bit = GPIO_PIN_0;
    sd_cb.CD_Bit = GPIO_PIN_1;
    msi_cb.ioctl_code = MSI_IOCTL_SD_CARD_ATTACH;
    msi_cb.set = &sd_cb;
    // Attach GPIO and SPI Master drivers to the SD Card...
    vos_dev_ioctl(hSDCard, &msi_cb);

    // Check there is a card connected...
    msi_cb.ioctl_code = MSI_IOCTL_SD_CARD_DETECT;
    vos_dev_ioctl(hSDCard, &msi_cb);
    if(*msi_cb.get != SD_CARD_PRESENT) {
        return;
    }

    // Check the card isn't write protected...
    msi_cb.ioctl_code = MSI_IOCTL_SD_WRITE_PROTECT;
    vos_dev_ioctl(hSDCard, &msi_cb);
    if(*msi_cb.get == SD_CARD_WRITE_PROTECTED) {
        return;
    }

    // Inititalize the SD Card in SPI mode...
    msi_cb.ioctl_code = MSI_IOCTL_SD_CARD_INIT;
    vos_dev_ioctl(hSDCard, &msi_cb);

    // Check the version of the SD Card connected...
    msi_cb.ioctl_code = MSI_IOCTL_SD_GET_CARD_TYPE;
    vos_dev_ioctl(hSDCard, &msi_cb);
    card_type = *msi_cb.get;

    // Set-up the context for the FAT driver...
    fat_iocb.ioctl_code = FAT_IOCTL_FS_ATTACH;
    fat_iocb.set = &fat_cb;
    fat_cb.msi_handle = hSDCard;
    fat_cb.partition = 0;
    // Attach the SD Card driver to the FAT driver...
    vos_dev_ioctl(hFat, &fat_iocb);
    // Attach the FAT driver to the FAT API...
    fsAttach(hFat);

    // Open a file for writing...
    file = fopen("TEST.TXT", "w+");

    // Write a string to the file on the SD Card...
    fwrite(s, 12, sizeof(char), file);
    fseek(file, 0, FAT_SEEK_SET);
    // Read a string from the SD Card...
    fread(s, 12, sizeof(char), file);
    fseek(file, 12, FAT_SEEK_SET);
    // Write the same string to the end of the file...
    fwrite(s, 12, sizeof(char), file);
    fclose(file);
    // Expected Output:
    // Hello World!Hello World!

    return;
}


