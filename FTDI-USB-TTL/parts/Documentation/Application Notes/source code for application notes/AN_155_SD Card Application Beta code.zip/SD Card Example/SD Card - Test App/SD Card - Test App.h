#define NUMBER_OF_DEVICES 4

#define VOS_DEV_SPIMASTER 0
#define VOS_DEV_SDCARD    1
#define VOS_DEV_FTFS      2
#define VOS_DEV_GPIO      3


