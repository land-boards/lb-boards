SD Card Driver Beta

The files SDCard.h, SDCard.a and FAT.a need to be placed in the correct folder location so that they can be picked up by the compiler.  The default location for the .a files would be the folder: C:\Program Files\FTDI\Vinculum II Toolchain\Firmware\Drivers\lib and for the .h file would be C:\Program Files\FTDI\Vinculum II Toolchain\Firmware\Drivers\include.  This is dependent on where on your system the IDE and toolchain have been installed.  These files must be copied to the correct location before compiling or the application will not build.

Both of these will be included in later releases of the toolchain.  For up to date version of the toolchain please refer to the FTDI website.