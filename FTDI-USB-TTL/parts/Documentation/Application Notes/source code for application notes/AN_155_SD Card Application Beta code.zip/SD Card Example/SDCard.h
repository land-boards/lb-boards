/*
** sdcard.h
**
** Copyright � 2010 Future Devices International Limited
**
** Header file for Vinculum II SD Card Driver
** Header File
**
** Author: David Clark
** Project: Vinculum II
** Module: Vinculum II Applications
** Requires: None
** Comments:
**
** History:
**  1 � Initial version
**
*/

#ifndef SD_H
#define SD_H

// SD Card Initialisation Function
unsigned char sd_init(unsigned char dev_num);
//==============================================================================
//  SD Card Context
//==============================================================================
/*typedef struct _sdcard_context
{
    VOS_HANDLE SPI_Handle;
    unsigned char sd_card_type;
    unsigned long sector_size;
    unsigned char write_protected;
} sdcard_context;*/

typedef struct _sdcard_ioctl_cb_attach_t
{
    VOS_HANDLE SPI_Handle;
    VOS_HANDLE GPIO_Handle;
    unsigned char WP_Bit;
    unsigned char CD_Bit;
} sdcard_ioctl_cb_attach_t;

//==============================================================================
//  SD Card IOCTLS
//==============================================================================
// TODO: Move this to the MSI header file?
#define     MSI_IOCTL_SD_CARD_ATTACH      0x01 // Attach SPI Master driver to SD Card driver.
#define     MSI_IOCTL_SD_CARD_INIT        0x02 // Init an SD Card in SPI mode.
#define     MSI_IOCTL_SD_GET_CARD_TYPE    0x03 // Return Card type, as list below.
#define     MSI_IOCTL_SD_CARD_DETECT      0x04 // Check for SD Card insertion.
#define     MSI_IOCTL_SD_CARD_WAIT_INSERT 0x05 // Wait for SD Card insertion.
#define     MSI_IOCTL_SD_WRITE_PROTECT    0x06 // Check for SD Card write protection.

#define     SD_IOCTL_UNKNOWN_COMMAND      0xFF

// SD Card Types
#define     SD_INV                        0xFF // Invalid SD Card
#define     SD_V1                         0x01 // v1.0 or less
#define     SD_V2                         0x02 // v2.0
#define     SD_HC                         0x03 // SD High Capacity card
#define     SD_MMC                        0x04 // MMC card not SD

#define     SD_CARD_PRESENT               0x01 // SD Card is detected.
#define     SD_CARD_WRITE_PROTECTED       0x01 // SD Card is write protected.

//==============================================================================
//  SD Card Return Codes
//==============================================================================
enum SD_CARD_STATUS {
    SD_SUCCESS = 0x00,
    SD_CARD_INITIALIZATION_FAILED,
    SD_INVALID_CARD,
    SD_CMD_FAILED,
    SD_READ_FAILED,
    SD_WRITE_FAILED,
    SD_FRAME_ERROR,
    SD_WRITE_PROTECTED,
    SD_CARD_FATAL_ERROR = 0xFF
};

#endif
