//---------------------------------------------------------------------------

#include <vcl.h>
#include <Clipbrd.hpp>
#include <stdio.h>
#include <fstream>
#pragma hdrstop

#include "ProcessWebcamData.h"
#include "ftd2xx.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TVinWebcam *VinWebcam;
int testVar = 0;
int globalSync = 0;
int WebcamStarted = 0;
FT_HANDLE fthandle;
int testidx = 0;
int showImage = 0;
int imageReady = 0;
int len, actual, remain;
unsigned char YuYBuffer[YUV_IMAGE_SIZE+1];
unsigned char RGBData[RGB_IMAGE_SIZE + 1];
//unsigned char EnlargedRGBData[ENLARGED_RGB_IMAGE_SIZE + 1];
unsigned char ZoomedRGBData[ZOOM4_RGB_IMAGE_SIZE + 1];
unsigned char TempBuffer[192];

char idxExt[10];
char Filename[100] = "bmpData";
char FullFileName[100];
char *Ext = ".bmp";
int exitThread = 0;
int Enlarge = 0;
int Zoom = 1;
int HardwareInitFlag = 0;


HANDLE hThread;
//HANDLE hMutex;

/*
A typical BMP file usually contains the following blocks of data:

BMP File Header 	Stores general information about the BMP file.

Bitmap Information
(DIB header) 		Stores detailed information about the bitmap image.

Color Palette 		Stores the definition of the colors being used for
					indexed color bitmaps.

Bitmap Data 		Stores the actual image, pixel by pixel.

*/

bmpfile_header HardcodeBMPFile_header;
//bmpfile_header HardcodedEnlargedBMPFile_header;
bmpfile_header Zoom1HardcodeBMPFile_header;
bmpfile_header Zoom2HardcodeBMPFile_header;
bmpfile_header Zoom3HardcodeBMPFile_header;
bmpfile_header Zoom4HardcodeBMPFile_header;








bmp_dib_v3_header Hardcode_bmp_dib_v3_header;
//bmp_dib_v3_header HardcodeEnlarged_bmp_dib_v3_header;
bmp_dib_v3_header Zoom1Hardcode_bmp_dib_v3_header;
bmp_dib_v3_header Zoom2Hardcode_bmp_dib_v3_header;
bmp_dib_v3_header Zoom3Hardcode_bmp_dib_v3_header;
bmp_dib_v3_header Zoom4Hardcode_bmp_dib_v3_header;


int Resample(unsigned char *ResizedData,unsigned char *OriginalData,int newWidth, int newHeight, int oriWidth,int oriHeight)
{
	double scaleWidth =  (double)newWidth / (double)oriWidth;
	double scaleHeight = (double)newHeight / (double)oriHeight;
	int cy,cx;
	for(cy = 0; cy < newHeight; cy++)
	{
		for(cx = 0; cx < newWidth; cx++)
		{
			int pixel = (cy * (newWidth *3)) + (cx*3);
			int nearestMatch =  (((int)(cy / scaleHeight) * (oriWidth *3)) + ((int)(cx / scaleWidth) *3) );

			ResizedData[pixel    ] =  OriginalData[nearestMatch    ];
			ResizedData[pixel + 1] =  OriginalData[nearestMatch + 1];
			ResizedData[pixel + 2] =  OriginalData[nearestMatch + 2];
		}
	}


	return 1;
}






void YUY2RGBConvert (unsigned char inputBuffer1[],
						unsigned char OutputBuffer2[],
						int size)
{
	double Blue, Green, Red;
	double Y0, Y1, U, V;
	int inIdx = 0, outIdx = 0;
	int pxcount = 0;

	while (pxcount < size)
	{
		Y0 = inputBuffer1[inIdx++];
		U = inputBuffer1[inIdx++];
		Y1 = inputBuffer1[inIdx++];
		V = inputBuffer1[inIdx++];

		pxcount += 2;

		Blue = 1.164 * (Y0 - 16) + 2.018 * (U - 128);
		Green = 1.164 * (Y0 - 16) - 0.813 * (V - 128) - 0.391 * (U - 128);
		Red = 1.164 * (Y0 - 16) + 1.596 * (V - 128);

		#if 0
		/*Just to eliminte Multiply //testing*/
		Blue = (Y0 - 16) + (U - 128);
		Green = (Y0 - 16) - (V - 128) - (U - 128);
		Red = (Y0 - 16) +  (V - 128);
		#endif



		OutputBuffer2[outIdx++] = Red;
		OutputBuffer2[outIdx++] = Green;
		OutputBuffer2[outIdx++] = Blue;


		Blue = 1.164 * (Y1 - 16) + 2.018 * (U - 128);
		Green = 1.164 * (Y1 - 16) - 0.813 * (V - 128) - 0.391 * (U - 128);
		Red = 1.164 * (Y1 - 16) + 1.596 * (V - 128);

		#if 0
		/*Just to eliminte Multiply //testing*/
		Blue = (Y1 - 16) + (U - 128);
		Green = (Y1 - 16) - (V - 128) - (U - 128);
		Red = (Y1 - 16) +  (V - 128);
		#endif


		OutputBuffer2[outIdx++] = Red;
		OutputBuffer2[outIdx++] = Green;
		OutputBuffer2[outIdx++] = Blue;

	}
	outIdx = 0;
	return;
}



//---------------------------------------------------------------------------
__fastcall TVinWebcam::TVinWebcam(TComponent* Owner)
	: TForm(Owner)
{

}
//---------------------------------------------------------------------------







void TVinWebcam::ShowStartImage1(void)
{
	Image1->Picture->LoadFromFile("LoadingVideo1.bmp");
	Sleep(30);

}


void TVinWebcam::ShowStartImage2(void)
{
	Image1->Picture->LoadFromFile("LoadingVideo2.bmp");
	Sleep(30);

}
void TVinWebcam::ShowStartImage3(void)
{
	Image1->Picture->LoadFromFile("LoadingVideo3.bmp");
	Sleep(30);

}
void TVinWebcam::ShowStartImage4(void)
{
	Image1->Picture->LoadFromFile("LoadingVideo4.bmp");
	Sleep(30);

}


void __fastcall TVinWebcam::ShowStarVideo(TObject *Sender)
{
	if (WebcamStarted == 0)
	{
		if (testVar == 0)
		{
			ShowStartImage1();
		}
		else if (testVar == 1)
		{
			ShowStartImage2();
		}
		else if (testVar == 2)
		{
			ShowStartImage3();
		}
		else if (testVar == 3)
		{
			ShowStartImage4();
		}
		testVar++;
		if(testVar == 4)
			testVar = 0;
   	}
}
//---------------------------------------------------------------------------


/*
Hard code value for 160 * 120 BMP image

BMP header
Magic No   	2 bytes
		0x42
		0x4d

filesz     	4 bytes
		0x0000e136 // i.e (160 * 120 * 3) + 36 bytes header

creator1    2 bytes
		0x0000
creator2    2 bytes
		0x0000
bmp_offset	4 bytes
		0x00000036

Bitmap Information


Eh 			4 		the size of this header (40 bytes)
		0x00000028	// i.e 40 bytes
12h 		4 		the bitmap width in pixels (signed integer).
		0x000000a0	// 160
16h 		4 		the bitmap height in pixels (signed integer).
		0x00000078  //120
1Ah 		2 		the number of color planes being used. Must be set to 1.
		0x0001
1Ch 		2 		the number of bits per pixel, which is the color depth of the image. Typical values are 1, 4, 8, 16, 24 and 32.
		0x0018     //24
1Eh 		4 		the compression method being used. See the next table for a list of possible values.
		0x00000000
22h 		4 		the image size. This is the size of the raw bitmap data (see below), and should not be confused with the file size.
		0x0000e100
26h 		4 		the horizontal resolution of the image. (pixel per meter, signed integer)
		0x00000000
2Ah 		4 		the vertical resolution of the image. (pixel per meter, signed integer)
		0x00000000
2Eh 		4 		the number of colors in the color palette, or 0 to default to 2n.
		0x00000000
32h 		4 		the number of important colors used, or 0 when every color is important; generally ignored.
		0x00000000
Followed by RGB data


*/

void initBMPHeaders()
{
	/*Hard coding BMP header*/
	HardcodeBMPFile_header.filesz = (RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	HardcodeBMPFile_header.creator1 = 0;
	HardcodeBMPFile_header.creator2 = 0;
	HardcodeBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	Hardcode_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	Hardcode_bmp_dib_v3_header.width = 160;
	Hardcode_bmp_dib_v3_header.height =120;
	Hardcode_bmp_dib_v3_header.nplanes = 1;
	Hardcode_bmp_dib_v3_header.bitspp = 24;
	Hardcode_bmp_dib_v3_header.compress_type = 0;
	Hardcode_bmp_dib_v3_header.bmp_bytesz = RGB_IMAGE_SIZE;
	Hardcode_bmp_dib_v3_header.hres = 0;
	Hardcode_bmp_dib_v3_header.vres = 0;
	Hardcode_bmp_dib_v3_header.ncolors = 0 ;
	Hardcode_bmp_dib_v3_header.nimpcolors = 0;
	#if 0
    /*Hard coding BMP header*/
	HardcodedEnlargedBMPFile_header.filesz = (ENLARGED_RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	HardcodedEnlargedBMPFile_header.creator1 = 0;
	HardcodedEnlargedBMPFile_header.creator2 = 0;
	HardcodedEnlargedBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	HardcodeEnlarged_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	HardcodeEnlarged_bmp_dib_v3_header.width = ENLARGED_IMAGE_SIZE_X;
	HardcodeEnlarged_bmp_dib_v3_header.height = ENLARGED_IMAGE_SIZE_Y;
	HardcodeEnlarged_bmp_dib_v3_header.nplanes = 1;
	HardcodeEnlarged_bmp_dib_v3_header.bitspp = 24;
	HardcodeEnlarged_bmp_dib_v3_header.compress_type = 0;
	HardcodeEnlarged_bmp_dib_v3_header.bmp_bytesz = ENLARGED_RGB_IMAGE_SIZE;
	HardcodeEnlarged_bmp_dib_v3_header.hres = 0;
	HardcodeEnlarged_bmp_dib_v3_header.vres = 0;
	HardcodeEnlarged_bmp_dib_v3_header.ncolors = 0 ;
	HardcodeEnlarged_bmp_dib_v3_header.nimpcolors = 0;
    #endif

	/*zoom1*/
	Zoom1HardcodeBMPFile_header.filesz = (ZOOM1_RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	Zoom1HardcodeBMPFile_header.creator1 = 0;
	Zoom1HardcodeBMPFile_header.creator2 = 0;
	Zoom1HardcodeBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	Zoom1Hardcode_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	Zoom1Hardcode_bmp_dib_v3_header.width = ZOOM1_IMAGE_SIZE_X;
	Zoom1Hardcode_bmp_dib_v3_header.height = ZOOM1_IMAGE_SIZE_Y;
	Zoom1Hardcode_bmp_dib_v3_header.nplanes = 1;
	Zoom1Hardcode_bmp_dib_v3_header.bitspp = 24;
	Zoom1Hardcode_bmp_dib_v3_header.compress_type = 0;
	Zoom1Hardcode_bmp_dib_v3_header.bmp_bytesz = ZOOM1_RGB_IMAGE_SIZE;
	Zoom1Hardcode_bmp_dib_v3_header.hres = 0;
	Zoom1Hardcode_bmp_dib_v3_header.vres = 0;
	Zoom1Hardcode_bmp_dib_v3_header.ncolors = 0 ;
	Zoom1Hardcode_bmp_dib_v3_header.nimpcolors = 0;



   	/*zoom2*/
	Zoom2HardcodeBMPFile_header.filesz = (ZOOM2_RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	Zoom2HardcodeBMPFile_header.creator1 = 0;
	Zoom2HardcodeBMPFile_header.creator2 = 0;
	Zoom2HardcodeBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	Zoom2Hardcode_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	Zoom2Hardcode_bmp_dib_v3_header.width = ZOOM2_IMAGE_SIZE_X;
	Zoom2Hardcode_bmp_dib_v3_header.height = ZOOM2_IMAGE_SIZE_Y;
	Zoom2Hardcode_bmp_dib_v3_header.nplanes = 1;
	Zoom2Hardcode_bmp_dib_v3_header.bitspp = 24;
	Zoom2Hardcode_bmp_dib_v3_header.compress_type = 0;
	Zoom2Hardcode_bmp_dib_v3_header.bmp_bytesz = ZOOM2_RGB_IMAGE_SIZE;
	Zoom2Hardcode_bmp_dib_v3_header.hres = 0;
	Zoom2Hardcode_bmp_dib_v3_header.vres = 0;
	Zoom2Hardcode_bmp_dib_v3_header.ncolors = 0 ;
	Zoom2Hardcode_bmp_dib_v3_header.nimpcolors = 0;


	/*zoom3*/
	Zoom3HardcodeBMPFile_header.filesz = (ZOOM3_RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	Zoom3HardcodeBMPFile_header.creator1 = 0;
	Zoom3HardcodeBMPFile_header.creator2 = 0;
	Zoom3HardcodeBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	Zoom3Hardcode_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	Zoom3Hardcode_bmp_dib_v3_header.width = ZOOM3_IMAGE_SIZE_X;
	Zoom3Hardcode_bmp_dib_v3_header.height = ZOOM3_IMAGE_SIZE_Y;
	Zoom3Hardcode_bmp_dib_v3_header.nplanes = 1;
	Zoom3Hardcode_bmp_dib_v3_header.bitspp = 24;
	Zoom3Hardcode_bmp_dib_v3_header.compress_type = 0;
	Zoom3Hardcode_bmp_dib_v3_header.bmp_bytesz = ZOOM3_RGB_IMAGE_SIZE;
	Zoom3Hardcode_bmp_dib_v3_header.hres = 0;
	Zoom3Hardcode_bmp_dib_v3_header.vres = 0;
	Zoom3Hardcode_bmp_dib_v3_header.ncolors = 0 ;
	Zoom3Hardcode_bmp_dib_v3_header.nimpcolors = 0;

	/*zoom4*/
	Zoom4HardcodeBMPFile_header.filesz = (ZOOM4_RGB_IMAGE_SIZE)+BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;
	Zoom4HardcodeBMPFile_header.creator1 = 0;
	Zoom4HardcodeBMPFile_header.creator2 = 0;
	Zoom4HardcodeBMPFile_header.bmp_offset = BMP_HEADER_SIZE + BITMAP_INFO_HEADER_SIZE+PALLET_SIZE;

	/*Hard coding bitmap information*/
	Zoom4Hardcode_bmp_dib_v3_header.header_sz = BITMAP_INFO_HEADER_SIZE;
	Zoom4Hardcode_bmp_dib_v3_header.width = ZOOM4_IMAGE_SIZE_X;
	Zoom4Hardcode_bmp_dib_v3_header.height = ZOOM4_IMAGE_SIZE_Y;
	Zoom4Hardcode_bmp_dib_v3_header.nplanes = 1;
	Zoom4Hardcode_bmp_dib_v3_header.bitspp = 24;
	Zoom4Hardcode_bmp_dib_v3_header.compress_type = 0;
	Zoom4Hardcode_bmp_dib_v3_header.bmp_bytesz = ZOOM4_RGB_IMAGE_SIZE;
	Zoom4Hardcode_bmp_dib_v3_header.hres = 0;
	Zoom4Hardcode_bmp_dib_v3_header.vres = 0;
	Zoom4Hardcode_bmp_dib_v3_header.ncolors = 0 ;
	Zoom4Hardcode_bmp_dib_v3_header.nimpcolors = 0;





}


int initHardware()
{
	FT_DEVICE_LIST_INFO_NODE *devInfo = NULL;
	DWORD numDevs;

	//FT_HANDLE fthandleA;
	FT_STATUS ftStatus;



	ftStatus = FT_CreateDeviceInfoList (&numDevs);
	if (ftStatus == FT_OK)
	{
		printf ("Number of devices is %d\n", numDevs);
	}
	else
	{
		printf ("fsStatus = %d\n", ftStatus);
		return -1;
	}


	ftStatus = FT_OpenEx((void *)"VII Eval Board A",FT_OPEN_BY_DESCRIPTION,&fthandle);

	if (ftStatus == FT_OK)
	{
		printf ("FT_Open(), device  Success status = %d\n", ftStatus);
	}
	else
	{
/*		while(ftStatus !=FT_OK)
		{
			ftStatus = FT_OpenEx((void *)"VII Eval Board A",FT_OPEN_BY_DESCRIPTION,&fthandle);

			if (ftStatus == FT_OK)
			{
				printf ("FT_Open(), device  Success status = %d\n", ftStatus);
			}
		}*/
        ftStatus = FT_Close(fthandle);
		free(fthandle);
		printf ("Error FT_Open(), device Status = %d\n", ftStatus);
		return -1;
	}



	FT_SetDataCharacteristics  (fthandle, FT_BITS_8, FT_STOP_BITS_1, FT_PARITY_NONE);
	if ((ftStatus = FT_SetBaudRate (fthandle, 6000000)) != FT_OK)
	{
		printf ("Error FT_SetBaudRate(%d)\n", ftStatus);
	}
	else
	{
		printf ("FT_SetBaudRate(%d)\n", ftStatus);
	}


	if ((ftStatus = FT_SetRts 	(fthandle) ) != FT_OK)
	{
		printf ("Error FT_SetRts(%d)\n", ftStatus);
		return -1;
	}
	else
	{
		printf ("FT_SetRts(%d)\n", ftStatus);
	}

	//use RTS/CTS flow control to avoid data loss
	FT_SetFlowControl(fthandle, FT_FLOW_RTS_CTS, 0, 0);
	return 1;
}



void syncToWebcamFrames(void)
{
	unsigned char syncd = 0;
	DWORD dwBytesRead;
	FT_STATUS ftStatus;

	// synchronize with the frame header
	while (syncd == 0)
	{

		ftStatus = FT_Read(fthandle, TempBuffer, 1 ,&dwBytesRead);
		if (TempBuffer[0] == 0x0C) {
			// could be a start of a webcam frame
			//printf(".");
			// burn the rest of the frame...
			ftStatus = FT_Read(fthandle, TempBuffer, 191 ,&dwBytesRead);
			// check for EOF bit
			if (TempBuffer[0] & WEBCAM_EOF_BIT == WEBCAM_EOF_BIT) {
				// Yup - it's synced to the webcam frames
				return ;// TempBuffer[0];
			}
		}

	}
	return;//0;

}



DWORD ReceiveDataFromWebcam(void)
{
	FILE *fpWr;
	unsigned char oneByte;
	long int counter = 0;
	FT_STATUS ftStatus;
	DWORD dwBytesWritten, dwBytesRead;
	int RGBCounter = (ImageXSize *ImageYSize *3);

	while (HardwareInitFlag == -1)
	{
		   HardwareInitFlag =  initHardware();
	}
	syncToWebcamFrames();
	//printf("done\n");
	while(1)
	{
		if(exitThread == 0)
        	return 1;
		len = remain;
		remain = 0;
		do
		{
			// read 1 frame of webcam data
			ftStatus = FT_Read (fthandle, TempBuffer, 192 , &dwBytesRead);
			if(ftStatus != FT_OK)
			{
				printf ("Error FT_Read(%d)\n", ftStatus );
			}

			if (TempBuffer[0] != 0x0C) {
				printf("Not synchronised!  Attempting resync: ");
				syncToWebcamFrames();
				printf("done\n");
				break;
			}

			if ((TempBuffer[1] & WEBCAM_EOF_BIT) == WEBCAM_EOF_BIT) {
				//printf("EOF %d\n", len);
				break;
			}
			if ((TempBuffer[1] & WEBCAM_ERR_BIT) == 0) {
				if ((len + 180) > YUV_IMAGE_SIZE)
				{
					remain = len + 180 - YUV_IMAGE_SIZE;
					actual = 180 - remain;
				}
				else
				{
					remain = 0;
					actual = 180;
				}
				memcpy(&YuYBuffer[len], &TempBuffer[12], actual);
				len += actual;
			}


		}
		while (len < YUV_IMAGE_SIZE);

		while(imageReady == 1)
		{
			;
		}
		itoa ( testidx, idxExt, 10 );
		testidx++;
		if(testidx == 100)
		{
			testidx = 0;
		}
		strcpy(FullFileName,Filename);
		strcat(FullFileName,idxExt);
		strcat(FullFileName,Ext);
		YUY2RGBConvert(YuYBuffer, RGBData,IMAGE_SIZE);
		fpWr = fopen(FullFileName,"wb+");
		oneByte = 0x42;
		fwrite(&oneByte,1,1,fpWr);
		oneByte = 0x4d;
		fwrite(&oneByte,1,1,fpWr);
		switch (Zoom)
		{
		case ZOOM1_SIZE:
        	Resample(ZoomedRGBData,RGBData,(int)ZOOM1_IMAGE_SIZE_X,(int)ZOOM1_IMAGE_SIZE_Y,(int)IMAGE_SIZE_X,(int)IMAGE_SIZE_Y);
			fwrite(&Zoom1HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Zoom1Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = ZOOM1_RGB_IMAGE_SIZE;
			for (counter = 0;counter < ZOOM1_RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&ZoomedRGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}

		break;
		case ZOOM2_SIZE:
			Resample(ZoomedRGBData,RGBData,(int)ZOOM2_IMAGE_SIZE_X,(int)ZOOM2_IMAGE_SIZE_Y,(int)IMAGE_SIZE_X,(int)IMAGE_SIZE_Y);
			fwrite(&Zoom2HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Zoom2Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = ZOOM2_RGB_IMAGE_SIZE;
			for (counter = 0;counter < ZOOM2_RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&ZoomedRGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}
		break;
		case ZOOM3_SIZE:
			Resample(ZoomedRGBData,RGBData,(int)ZOOM3_IMAGE_SIZE_X,(int)ZOOM3_IMAGE_SIZE_Y,(int)IMAGE_SIZE_X,(int)IMAGE_SIZE_Y);
			fwrite(&Zoom3HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Zoom3Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = ZOOM3_RGB_IMAGE_SIZE;
			for (counter = 0;counter < ZOOM3_RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&ZoomedRGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}
		break;
/*		case ZOOM4_SIZE:
			Resample(ZoomedRGBData,RGBData,(int)ZOOM4_IMAGE_SIZE_X,(int)ZOOM4_IMAGE_SIZE_Y,(int)IMAGE_SIZE_X,(int)IMAGE_SIZE_Y);
			fwrite(&Zoom4HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Zoom4Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = ZOOM4_RGB_IMAGE_SIZE;
			for (counter = 0;counter < ZOOM4_RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&ZoomedRGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}
		break;*/

		default:
			fwrite(&HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = RGB_IMAGE_SIZE;
			for (counter = 0;counter < RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&RGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			};
		}
/*		if(Enlarge == 0)
		{
			fwrite(&HardcodeBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&Hardcode_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = RGB_IMAGE_SIZE;
			for (counter = 0;counter < RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&RGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}
		}
		else
		{
			Resample(EnlargedRGBData,RGBData,(int)ENLARGED_IMAGE_SIZE_X,(int)ENLARGED_IMAGE_SIZE_Y,(int)IMAGE_SIZE_X,(int)IMAGE_SIZE_Y);
			fwrite(&HardcodedEnlargedBMPFile_header,sizeof(bmpfile_header),1,fpWr);
			fwrite(&HardcodeEnlarged_bmp_dib_v3_header,sizeof(bmp_dib_v3_header),1,fpWr);

			RGBCounter = ENLARGED_RGB_IMAGE_SIZE;
			for (counter = 0;counter < ENLARGED_RGB_IMAGE_SIZE;counter++)
			{
				fwrite(&EnlargedRGBData[RGBCounter-1],1,1,fpWr);
				RGBCounter--;
			}

		}*/

		fclose(fpWr);
		Sleep(1);
		imageReady = 1;



	}


	return 1;
}








void __fastcall TVinWebcam::Button1Click(TObject *Sender)
{
	FT_STATUS ftStatus;
	if (Button1->Caption == "Start Video")
	{
		Button1->Caption = "Stop Video";
		initBMPHeaders();
		//Timer1->Enabled = true;
		HardwareInitFlag = initHardware();
		Sleep(1);
		exitThread = 1;
		hThread = CreateThread(NULL,0,(LPTHREAD_START_ROUTINE)&ReceiveDataFromWebcam,0,0,NULL);
		Timer1->Enabled = true;
		Timer2->Enabled = true;

	}
	else
	{
		Timer1->Enabled = false;
		Timer2->Enabled = false;
		Image1->Picture->LoadFromFile("StreamingStopped.bmp");
		//destroy thread
		//need to stop the thread?????/????
		exitThread = 0;
		CloseHandle(hThread);
		//free hardware handle
		ftStatus = FT_Close(fthandle);
		free(fthandle);
		Button1->Caption = "Start Video";
	}




}
//---------------------------------------------------------------------------






void __fastcall TVinWebcam::ShowWebcamData(TObject *Sender)
{
	if (imageReady == 1)
	{
        Timer1->Enabled = false;
		Image1->Picture->LoadFromFile(FullFileName);
		remove(FullFileName);
		imageReady = 0;
	}

}
//---------------------------------------------------------------------------




void __fastcall TVinWebcam::Button2Click(TObject *Sender)
{
	Zoom++;	
	if (Button3->Enabled != true) 
		Button3->Enabled = true;
	//if (Zoom == ZOOM4_SIZE)
	if (Zoom == ZOOM3_SIZE)
	{
	  Button2->Enabled = false;	
	}
	/*if(Enlarge == 1)
	{
	   Button2->Caption = "Enlarge";
	   Enlarge = 0;
	}
	else
	{
		Button2->Caption = "ActualSize";
		Enlarge = 1;
    } */
}
//---------------------------------------------------------------------------

void __fastcall TVinWebcam::Button3Click(TObject *Sender)
{
	if (Zoom == ZOOM1_SIZE) 
	{
	   Button3->Enabled = false;	
	}
	Zoom --;
	if (Button2->Enabled != true) 
		Button2->Enabled = true;
	
}
//---------------------------------------------------------------------------

