//---------------------------------------------------------------------------

#ifndef ProcessWebcamDataH
#define ProcessWebcamDataH
//---------------------------------------------------------------------------
#include <Classes.hpp>
#include <Controls.hpp>
#include <StdCtrls.hpp>
#include <Forms.hpp>
#include <ExtCtrls.hpp>
#include <Graphics.hpp>


#define TESTING						1 // make this to 0 for disabling testing

#define ImageXSize					160
#define ImageYSize					120
#define BMP_HEADER_SIZE     		14
#define BITMAP_INFO_HEADER_SIZE		40
#define PALLET_SIZE					0


#define WEBCAM_EOF_BIT		0x02
#define WEBCAM_TOG_BIT		0x01
#define WEBCAM_ERR_BIT		0x40

#define IMAGE_SIZE_X			ImageXSize
#define IMAGE_SIZE_Y			ImageYSize
#define	ZOOM1_SIZE				2
#define	ZOOM2_SIZE				(ZOOM1_SIZE + 1)
#define	ZOOM3_SIZE				(ZOOM2_SIZE + 1)
#define	ZOOM4_SIZE				(ZOOM3_SIZE + 1)
#define ENLARGE_SIZE			3    		//number of time to enlarge
#define ENLARGED_IMAGE_SIZE_X  	(ImageXSize*ENLARGE_SIZE)
#define ENLARGED_IMAGE_SIZE_Y  	(ImageYSize*ENLARGE_SIZE)
#define ZOOM1_IMAGE_SIZE_X  	(ImageXSize*ZOOM1_SIZE)
#define ZOOM1_IMAGE_SIZE_Y  	(ImageYSize*ZOOM1_SIZE)
#define ZOOM2_IMAGE_SIZE_X  	(ImageXSize*ZOOM2_SIZE)
#define ZOOM2_IMAGE_SIZE_Y  	(ImageYSize*ZOOM2_SIZE)
#define ZOOM3_IMAGE_SIZE_X  	(ImageXSize*ZOOM3_SIZE)
#define ZOOM3_IMAGE_SIZE_Y  	(ImageYSize*ZOOM3_SIZE)
#define ZOOM4_IMAGE_SIZE_X  	(ImageXSize*ZOOM4_SIZE)
#define ZOOM4_IMAGE_SIZE_Y  	(ImageYSize*ZOOM4_SIZE)



#define IMAGE_SIZE          		(IMAGE_SIZE_X *IMAGE_SIZE_Y)
#define ENLARGE_IMAGE_SIZE			(ENLARGED_IMAGE_SIZE_X*ENLARGED_IMAGE_SIZE_Y)
#define ZOOM1_IMAGE_SIZE          	(ZOOM1_IMAGE_SIZE_X *ZOOM1_IMAGE_SIZE_Y)
#define ZOOM2_IMAGE_SIZE          	(ZOOM2_IMAGE_SIZE_X *ZOOM2_IMAGE_SIZE_Y)
#define ZOOM3_IMAGE_SIZE          	(ZOOM3_IMAGE_SIZE_X *ZOOM3_IMAGE_SIZE_Y)
#define ZOOM4_IMAGE_SIZE          	(ZOOM4_IMAGE_SIZE_X *ZOOM4_IMAGE_SIZE_Y)





#define YUV_IMAGE_SIZE				(IMAGE_SIZE*2)
#define RGB_IMAGE_SIZE				(IMAGE_SIZE*3)
#define ENLARGED_RGB_IMAGE_SIZE		(ENLARGE_IMAGE_SIZE*3)
#define ZOOM1_RGB_IMAGE_SIZE		(ZOOM1_IMAGE_SIZE*3)
#define ZOOM2_RGB_IMAGE_SIZE		(ZOOM2_IMAGE_SIZE*3)
#define ZOOM3_RGB_IMAGE_SIZE		(ZOOM3_IMAGE_SIZE*3)
#define ZOOM4_RGB_IMAGE_SIZE		(ZOOM4_IMAGE_SIZE*3)

/*
BMP File Header

Offset# Size	 	Purpose

0000h 	2 bytes 	the magic number used to identify the BMP file,
					usually 0x42 0x4D in hex, same as BM in ASCII.
					The following entries are possible:

					* BM � Windows 3.1x, 95, NT, ... etc
					* BA � OS/2 Bitmap Array
					* CI � OS/2 Color Icon
					* CP � OS/2 Color Pointer
					* IC � OS/2 Icon
					* PT � OS/2 Pointer

0002h 	4 bytes 	the size of the BMP file in bytes
0006h 	2 bytes 	reserved; actual value depends on the application
					that creates the image
0008h 	2 bytes 	reserved; actual value depends on the application
					that creates the image
000Ah 	4 bytes 	the offset, i.e. starting address, of the byte where the
					bitmap data can be found

*/

typedef struct bmpfile_header_t {
  uint32_t filesz;
  uint16_t creator1;
  uint16_t creator2;
  uint32_t bmp_offset;
}bmpfile_header;



/*

Bitmap Information

Offset # 	Size 	Purpose
Eh 			4 		the size of this header (40 bytes)
12h 		4 		the bitmap width in pixels (signed integer).
16h 		4 		the bitmap height in pixels (signed integer).
1Ah 		2 		the number of color planes being used. Must be set to 1.
1Ch 		2 		the number of bits per pixel, which is the color depth of the image. Typical values are 1, 4, 8, 16, 24 and 32.
1Eh 		4 		the compression method being used. See the next table for a list of possible values.
22h 		4 		the image size. This is the size of the raw bitmap data (see below), and should not be confused with the file size.
26h 		4 		the horizontal resolution of the image. (pixel per meter, signed integer)
2Ah 		4 		the vertical resolution of the image. (pixel per meter, signed integer)
2Eh 		4 		the number of colors in the color palette, or 0 to default to 2n.
32h 		4 		the number of important colors used, or 0 when every color is important; generally ignored.


Note: The image size field can be 0 for BI_RGB bitmaps.

*/

typedef struct bmp_dib_v3_header_t{
  uint32_t header_sz;
  uint32_t width;
  uint32_t height;
  uint16_t nplanes;
  uint16_t bitspp;
  uint32_t compress_type;
  uint32_t bmp_bytesz;
  uint32_t hres;
  uint32_t vres;
  uint32_t ncolors;
  uint32_t nimpcolors;
} bmp_dib_v3_header;


/*Compression Method*/
/*
typedef enum {
  BI_RGB = 0,
  BI_RLE8,
  BI_RLE4,
  BI_BITFIELDS,
  BI_JPEG,
  BI_PNG,
} bmp_compression_method_t;
  */



//---------------------------------------------------------------------------
class TVinWebcam : public TForm
{
__published:	// IDE-managed Components
	TImage *Image1;
	TTimer *Timer1;
	TButton *Button1;
	TTimer *Timer2;
	TButton *Button2;
	TButton *Button3;
	void __fastcall ShowStarVideo(TObject *Sender);
	void __fastcall Button1Click(TObject *Sender);
	void __fastcall ShowWebcamData(TObject *Sender);
	void __fastcall Button2Click(TObject *Sender);
	void __fastcall Button3Click(TObject *Sender);

private:	// User declarations

	void ShowStartImage1(void);
	void ShowStartImage2(void);
	void ShowStartImage3(void);
	void ShowStartImage4(void);
public:		// User declarations
	__fastcall TVinWebcam(TComponent* Owner);

};
//---------------------------------------------------------------------------
extern PACKAGE TVinWebcam *VinWebcam;
//---------------------------------------------------------------------------
#endif
