The Part 1 examples use the same source code for Windows and OS X platforms.

These files are in a .dmg file for easy installation on a Mac

The "#define OnWindows"  in stdafx.h should not be commented out for Windows operation.

My beta testers had various problems integrating the source code into Visual Studio 2008 projects 
so I decided to include the complete solutions here.  The .dmg file contains XCode projects.

You should also download the Windows or OS X drivers from http://www.ftdichip.com/Drivers/D2XX.htm

If you have any comments, questions or suggestions please email me at john@USB-By-Example.com

Have fun!   John
