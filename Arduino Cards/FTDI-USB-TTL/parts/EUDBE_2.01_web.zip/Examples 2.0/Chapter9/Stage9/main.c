/*
** Main.c module for Chapter9 Example (Stage9)
**
** Author:  John Hyde, USB Design By Example
*/

// Include global definitions, constants, etc
#include "main.h"

rom char BlinkStarted[] = "\nBlink (ID=%d) started";
rom char SlaveOpenned[] = "\nSlave Openned, SETUP thread (%d) started";
rom char SetupReceived[] = "\nSetup received:";
rom char FindKeyboardStarted[] = "\nFindKeyboard (%d) started ";
rom char KeyboardFound[] = "\n\nKeyboard found (%X)";
rom char FindMouseStarted[] = "\nFindMouse (%d) started ";
rom char MouseFound[] = "\n\nMouse found (%X)";
rom char ForwardReportsStarted[] = "\nForwardReports (%d) started ";
rom char SendReportsStarted[] = "\nSendReports (%d) Started ";
rom char RecordButtonOn[] = "\nMonitoring Record Button";
rom char RecordStarted[] = "\nRecord (%d) started";
rom char RecordingStarted[] = "\nRecording Started";
rom char RecordingStopped[] = "\nRecording Stopped";
rom char PlaybackButtonOn[] = "\nMonitoring Playback Button";
rom char PlaybackStarted[] = "\nPlayback (%d) started ";
rom char PlaybackComplete[] = "\nPlayback completed";
rom char MemChkIs[] = "\nMemChk(%d)=";
rom char TCBPtrIs[] = "\nTCB_Ptr(%d)=";
rom char PerCentDandX[] = "%D (0x%X)";
rom char StackAllocated[] = ", Stack Allocated = %D";
rom char StackUsed[] = ", Stack Used = %D";
rom char CountIs[] = ", Count = %L";
rom char TCBIs[] = "\nContents of TCB(%d) are:";
rom char StatsDone[] = "\n\nStats done\n";

// Declare global variables
VOS_HANDLE hDevice[NUMBER_OF_DEVICES];
vos_semaphore_t DevicesStarted;
vos_mutex_t dprintLock;
WORD Delay;
MessageType KeyboardMessage;
char KeyboardName[] = "Keyboard";
vos_semaphore_t EnumerationComplete;
vos_semaphore_t SendKeyboardReport;
vos_semaphore_t KeyboardReportReceived;
MessageType RecordMessage;
EntryType Entry;
vos_semaphore_t RecordThisReport;
BOOL Recording;
vos_semaphore_t RecordControl;
MessageType PlaybackMessage;
vos_semaphore_t StartPlayback;
vos_semaphore_t SendPlaybackReport;
MessageType MouseMessage;
vos_semaphore_t SendMouseReport;
vos_semaphore_t MouseReportReceived;
char MouseName[] = "Mouse";
vos_mutex_t SearchHostLock;

vos_tcb_t* TCB_Ptr[NUMBER_OF_THREADS+1];
void* MemChk[3];

void CheckStatus(BYTE Status, BYTE ErrorCode) {
    BYTE Reason;
    if (Status == 0) return;
// Set a breakpoint at the next line so that this error can be resolved
    Reason = ErrorCode;
    }

void* MemCheck(BYTE ID) {
// Used to determine the amount of free memory available
    MemChk[ID] = vos_malloc(16);
    vos_free(MemChk[ID]);
    return MemChk[ID];
    }

void DisplayStats(void) {
    BYTE i;
    WORD Temp;
    DWORD Count;
    for (i=0; i<(sizeof(MemChk)/sizeof(MemChk[0])); i++) {
        dprint(&MemChkIs[0], &i);
        dprint(&PerCentDandX[0], &MemChk[i]);
        }
    for (i=0; i<NUMBER_OF_THREADS; i++) {
        dprint(&TCBPtrIs[0], &i);
        dprint(&PerCentDandX[0], &TCB_Ptr[i]);
// How much stack has been allocated to this thread, and how much has been used?
        Temp = TCB_Ptr[i+1] - TCB_Ptr[i] - 56;
        dprint(&StackAllocated[0], &Temp);
        Temp = vos_stack_usage(TCB_Ptr[i]);
        dprint(&StackUsed[0], &Temp);
        Count = vos_get_profile(TCB_Ptr[i]);
        dprint(&CountIs[0], &Count);
        }
// Replace (0) with (1) to display contents of each TCB
#if (0)
    for (i=0; i<NUMBER_OF_THREADS; i++) {
        dprint(&TCBIs[0], &i);
        dprintBuffer((BYTE*)TCB_Ptr[i], (int)(TCB_Ptr[i+1] - TCB_Ptr[i]));
        vos_delay_msecs(4000); // Don't flood V2EvalTerm
        }
#endif
    dprint(&StatsDone[0], 0);
    }

void WaitForDevicesStarted(void) {
    vos_wait_semaphore(&DevicesStarted);
    vos_signal_semaphore(&DevicesStarted);
    }

// Declare program thread(s)
// Blink thread, toggles LED3 on GPIO1. Stop blinking during Recording
void Blink(BYTE ThreadID) {
    BYTE Value;
    WORD Time = 0;
    BYTE PortData = LED3;
    vos_start_profiler();
    WaitForDevicesStarted();
    dprint(&BlinkStarted[0], &ThreadID);
    while (1) {
        i_vos_delay_msecs(ThreadID, Delay);
        PortData ^= LED3;
        Value = (Recording) ? ~LED3 : PortData;
// Now write pattern to the GPIO port.
        i_vos_dev_write(ThreadID, hDevice[LEDs] ,&Value, 1, NULL);
// After about 1 minute display some stats
        if (++Time == 250) DisplayStats();
        }
    }

void EnumerateSlave (BYTE ThreadID) {
    usbslave_ioctl_cb_t iocb;
    BYTE SetupBuffer[9];
    BYTE Status;
    WaitForDevicesStarted();
    dprint(&SlaveOpenned[0], &ThreadID);
    iocb.ioctl_code = VOS_IOCTL_USBSLAVE_WAIT_SETUP_RCVD;
    iocb.request.setup_or_bulk_transfer.buffer = &SetupBuffer[0];
    iocb.request.setup_or_bulk_transfer.size = sizeof(SetupBuffer);
    while (1) {
        Status = i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
        dprint(&SetupReceived[0], 0);
        dprintBuffer(&SetupBuffer[0], sizeof(SetupBuffer));
        HandleRequest(ThreadID, (usb_deviceRequest_t*)&SetupBuffer[0]);
        }
    }

void FindKeyboard(BYTE ThreadID) {
// This thread looks for a keyboard attached to Host[2]
// It owns KeyboardMessage at startup
    usbhost_device_handle* ifDev;
    WaitForDevicesStarted();
    dprint(&FindKeyboardStarted[0], &ThreadID);
    while (1) {
        ifDev = WaitForKeyboard(ThreadID);
        dprint(&KeyboardFound[0], &ifDev);
        KeyboardMessage.ReportLength = 8;
        KeyboardMessage.SignalSemaphore = &KeyboardReportReceived;
        KeyboardMessage.NamePtr = &KeyboardName[0];
        GetReports(ThreadID, ifDev, &KeyboardMessage);
        }
    }

void FindMouse(BYTE ThreadID) {
// This thread looks for a mouse attached to Host[2]
// It owns MouseMessage at startup
    usbhost_device_handle* ifDev;
    WaitForDevicesStarted();
    dprint(&FindMouseStarted[0], &ThreadID);
    while (1) {
        ifDev = WaitForMouse(ThreadID);
        dprint(&MouseFound[0], &ifDev);
        MouseMessage.SignalSemaphore = &MouseReportReceived;
        MouseMessage.ReportLength = 3;
        MouseMessage.NamePtr = &MouseName[0];
        GetReports(ThreadID, ifDev, &MouseMessage);
        }
    }

void ForwardReports(BYTE ThreadID) {
// Now waits on two semaphores
    BYTE Index;
    BYTE Report[MaxReportLength];
    vos_semaphore_list_t* SemaphoreList;
    vos_semaphore_t Returned;
    vos_init_semaphore(&Returned, 0);
// This thread owns RecordMessage at startup
    RecordMessage.ReportBuffer = &Report[0];
    RecordMessage.ResponseSemaphore = &Returned;
    WaitForDevicesStarted();
    SemaphoreList = (vos_semaphore_list_t*) vos_malloc(VOS_SEMAPHORE_LIST_SIZE(2));
    dprint(&ForwardReportsStarted[0], &ThreadID);
    while (1) {
// Wait for a keyboard or a mouse report
        SemaphoreList->next = NULL;
        SemaphoreList->siz = 2;
        SemaphoreList->flags = VOS_SEMAPHORE_FLAGS_WAIT_ANY;
        SemaphoreList->list[0] = &KeyboardReportReceived;
        SemaphoreList->list[1] = &MouseReportReceived;
// Wait for ownership of KeyboardReport (Index=0) or MouseReport (Index=1)
        Index = vos_wait_semaphore_ex(SemaphoreList);
// Need to make a copy since I will be forwarding the report and therefore will not own it
        if (Index) {  // It is a Mouse Report
            memcpy(&Report[0], MouseMessage.ReportBuffer, 3);
            RecordMessage.ReportLength = 3;
// Forward the Report to the Mouse Slave
            i_vos_signal_semaphore(ThreadID, &SendMouseReport);
            }
        else {        // It is a Keyboard Report
            memcpy(&Report[0], KeyboardMessage.ReportBuffer, 8);
            RecordMessage.ReportLength = 8;
// Forward the Report to the Keyboard Slave
            i_vos_signal_semaphore(ThreadID, &SendKeyboardReport);
            }
// Send a copy to Record and wait for the Return of ownership of RecordMessage
        i_vos_signal_semaphore(ThreadID, &RecordThisReport);
        i_vos_wait_semaphore(ThreadID, &Returned);
        }
    }

void SendReports(BYTE ThreadID) {
// Now checks three semaphores
    BYTE Status, Index;
    MessageType* Message;
    usbslave_ioctl_cb_t iocb;
    vos_semaphore_list_t* SemaphoreList;
    WaitForDevicesStarted();
    dprint(&SendReportsStarted[0], &ThreadID);
    SemaphoreList = (vos_semaphore_list_t*) vos_malloc(VOS_SEMAPHORE_LIST_SIZE(3));
    iocb.ioctl_code = VOS_IOCTL_USBSLAVE_TRANSFER;
    while (1) {
// Initialize the semaphore list that I will wait upon
        SemaphoreList->next = NULL;
        SemaphoreList->siz = 3;
        SemaphoreList->flags = VOS_SEMAPHORE_FLAGS_WAIT_ANY;
        SemaphoreList->list[0] = &SendKeyboardReport;
        SemaphoreList->list[1] = &SendPlaybackReport;
        SemaphoreList->list[2] = &SendMouseReport;
// Wait for ownership of KeyboardMessage (Index=0), PlaybackMessage (Index=1) or MouseMessage (Index=2)
        Index = vos_wait_semaphore_ex(SemaphoreList);
        switch (Index) {
            case 0: Message = &KeyboardMessage; break;
            case 1: Message = &PlaybackMessage; break;
            case 2: Message = &MouseMessage; break;
            }
        iocb.handle = Message->DataEP;
        iocb.request.setup_or_bulk_transfer.buffer = Message->ReportBuffer;
        iocb.request.setup_or_bulk_transfer.size = Message->ReportLength;
        Status = i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
        CheckStatus(Status, ErrorCouldNotSendReport);
// Give back Message
        i_vos_signal_semaphore(ThreadID, Message->ResponseSemaphore);
        }
    }

void Record(BYTE ThreadID) {
// Now checks two semaphores
    vos_semaphore_list_t* SemaphoreList;
    AtmelType Atmel;
    EntryType Entry;
    BYTE Index;
    BOOL FinishedRecording;
    WORD AtmelBlock = 0;
    WORD AtmelIndex = 0;
    Atmel.DontCare = 0;
    memset(&Entry, 0, sizeof(Entry));
    SemaphoreList = (vos_semaphore_list_t*) vos_malloc(VOS_SEMAPHORE_LIST_SIZE(2));
    WaitForDevicesStarted();
    dprint(&RecordStarted[0], &ThreadID);
// Check that the DataFlash is connected and in binary page mode
    if (CheckDataFlash(ThreadID)) {
        while (1) {
// Need to initialize semaphore list every time
            SemaphoreList->next = NULL;
            SemaphoreList->siz = 2;
            SemaphoreList->flags = VOS_SEMAPHORE_FLAGS_WAIT_ANY;
            SemaphoreList->list[0] = &RecordThisReport;
            SemaphoreList->list[1] = &RecordControl;
// Wait for a Report to be recorded (Index=0) OR a signal on RecordControl (Index=1)
            Index = vos_wait_semaphore_ex(SemaphoreList);
            FinishedRecording = (Index && !Recording);
            Entry.Tag = 0;
            memset(&Entry.KeyboardReport[0], 0, 11);    // Clear Keyboard and Mouse entries
            if (!Index && (RecordMessage.ReportLength == 8)) {
                Entry.Tag = ValidKeyboardReport;
// Copy the Report into the Entry stucture (this saves multiple SPI Writes later)
                memcpy(&Entry.KeyboardReport[0], RecordMessage.ReportBuffer, 8);
                }
             if (!Index && (RecordMessage.ReportLength == 3)) {
                Entry.Tag = ValidMouseReport;
                memcpy(&Entry.MouseReport[0], RecordMessage.ReportBuffer, 3);
                }
            if ((Entry.Tag && Recording) || FinishedRecording) {
// Copy Report or 0 terminator to Atmel DataFlash
                Entry.AtmelCommand = (AtmelBlock & 1) ? AtmelWriteBuffer2 : AtmelWriteBuffer1;
                Entry.BufferAddress = Swap(AtmelIndex);
                Entry.ElapsedTime = GetElapsedTime();
                Entry.Index++;
                SendAndReceiveSPIBytes(ThreadID, &Entry.AtmelCommand, sizeof(Entry), 0);
                AtmelIndex += 16;
                if ((AtmelIndex >= 512) || FinishedRecording) {
// Buffer is full, copy it to Flash memory and start filling the other buffer
                    Atmel.Command = (AtmelBlock & 1) ? AtmelProgramWithBuffer2: AtmelProgramWithBuffer1;
                    Atmel.Address = Swap(AtmelBlock<<1);
                    SendAndReceiveSPIBytes(ThreadID, &Atmel.Command, sizeof(Atmel), 0);
                    AtmelIndex = 0;
                    AtmelBlock++;
                    }
                }
// Return ownership of RecordMessage
            i_vos_signal_semaphore(ThreadID, RecordMessage.ResponseSemaphore);
            }
        }
    else {
        vos_free(SemaphoreList);
        CheckStatus(1, ErrorNoDataFlash);
        }
    }

void Playback(BYTE ThreadID) {
    DWORD AtmelAddress;
    MemoryReadEntryType Entry;
    vos_semaphore_t Returned;
    vos_init_semaphore(&Returned, 0);
// This thread owns PlaybackMessage at startup
    PlaybackMessage.ResponseSemaphore = &Returned;
    WaitForDevicesStarted();
    while (1) {
        vos_wait_semaphore(&StartPlayback);
        dprint(&PlaybackStarted[0], &ThreadID);
        AtmelAddress = 0;
        Entry.Tag = 1;
        while (Entry.Tag) {
// Read an entry from the Atmel
            memset(&Entry, 0xFF, sizeof(Entry));
            Entry.AtmelCommand = AtmelReadDirect;
            Entry.UpperAddress = (BYTE)AtmelAddress>>16;
            Entry.BufferAddress = Swap((WORD)AtmelAddress);
            SendAndReceiveSPIBytes(ThreadID, (BYTE*)&Entry, sizeof(Entry), 1);
            AtmelAddress += 16;
// Wait the elapsed time
            if (Entry.ElapsedTime > 4000) Entry.ElapsedTime = 4000;
            vos_delay_msecs(Entry.ElapsedTime);
// Fill out a ReportInfo and send the Report
            if (Entry.Tag == ValidKeyboardReport) {
                PlaybackMessage.ReportBuffer = &Entry.KeyboardReport[0];
                PlaybackMessage.ReportLength = 8;
                PlaybackMessage.DataEP = KeyboardMessage.DataEP;
                }
            if (Entry.Tag == ValidMouseReport) {
                PlaybackMessage.ReportBuffer = &Entry.MouseReport[0];
                PlaybackMessage.ReportLength = 3;
                PlaybackMessage.DataEP = MouseMessage.DataEP;
                }
            i_vos_signal_semaphore(ThreadID, &SendPlaybackReport);
            i_vos_wait_semaphore(ThreadID, &Returned);
            }
        dprint(&PlaybackComplete[0], 0);
        }
    }
void RecordButton(void) {
    gpio_ioctl_cb_t gpio_iocb;
    WaitForDevicesStarted();
    dprint(&RecordButtonOn[0], 0);
// Wait for a edges on Bit3
    gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_SET_PROG_INT0_PIN;
    gpio_iocb.value = GPIO_PIN_3;
    vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
    vos_enable_interrupts(VOS_GPIO_INT_IEN);
    while (1) {
// Wait on a button press
        gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_SET_PROG_INT0_MODE;
        gpio_iocb.value = GPIO_INT_ON_NEG_EDGE;
        vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
        gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_WAIT_ON_INT0;
        vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
// Returned from interrupt
        vos_delay_msecs(Debounce);
        Recording = !Recording;
        if (Recording) dprint(&RecordingStarted[0], 0);
        else dprint(&RecordingStopped[0], 0);
        vos_signal_semaphore(&RecordControl);
        }
    }

void PlaybackButton(void) {
    gpio_ioctl_cb_t gpio_iocb;
    WaitForDevicesStarted();
    dprint(&PlaybackButtonOn[0], 0);
// Wait for a edges on Bit7
    gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_SET_PROG_INT1_PIN;
    gpio_iocb.value = GPIO_PIN_7;
    vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
    while (1) {
// Wait on a button press
        gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_SET_PROG_INT1_MODE;
        gpio_iocb.value = GPIO_INT_ON_NEG_EDGE;
        vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
        gpio_iocb.ioctl_code = VOS_IOCTL_GPIO_WAIT_ON_INT1;
        vos_dev_ioctl(hDevice[Buttons], &gpio_iocb);
// Returned from interrupt
        vos_delay_msecs(Debounce);
        if (!Recording) vos_signal_semaphore(&StartPlayback);
        }
    }


void MyIdleTask(void) {
// This thread is always ready to run and effectively replaces VOS's IdleTask
// I toggle bit 7 of the Logic Analyser Port to show activity
    StartupDevices();
    while (1) {
        asm { ORPORT 393 $0x80; };
        asm {ANDPORT 393 $0x7F; };
        }
    }


// Declare Main application
void main(void) {
// Initialize variables
    vos_init_semaphore(&DevicesStarted, 0);
    vos_init_mutex(&dprintLock, VOS_MUTEX_UNLOCKED);
    Delay = 511;
    vos_init_semaphore(&EnumerationComplete, 0);
    vos_init_semaphore(&SendKeyboardReport, 0);
    vos_init_semaphore(&KeyboardReportReceived, 0);
    vos_init_semaphore(&RecordThisReport, 0);
    vos_init_semaphore(&RecordControl, 0);
    vos_init_semaphore(&StartPlayback, 0);
    vos_init_semaphore(&SendPlaybackReport, 0);
    vos_init_semaphore(&MouseReportReceived, 0);
    vos_init_semaphore(&SendMouseReport, 0);
    vos_init_mutex(&SearchHostLock, VOS_MUTEX_UNLOCKED);

// Initialise RTOS
    vos_init(VOS_QUANTUM, VOS_TICK_INTERVAL, NUMBER_OF_DEVICES);
    MemCheck(0);

// Sets the CPU frequency of the connected device.
    vos_set_clock_frequency(VOS_48MHZ_CLOCK_FREQUENCY);

// Initialise devices
    if (InitDevices()) {
        MemCheck(1);

// Initialise threads - pass a ThreadID to each thread
// Instrument memory usage to display in DisplayStats
        TCB_Ptr[0] = vos_create_thread(20, SmallTCB, &Blink, 1, 1);
        TCB_Ptr[1] = vos_create_thread(27, StandardTCB, &EnumerateSlave, 1, 0); // Not traced
        TCB_Ptr[2] = vos_create_thread(26, StandardTCB, &FindKeyboard, 1, 4);
        TCB_Ptr[3] = vos_create_thread(25, StandardTCB, &SendReports, 1, 8);
        TCB_Ptr[4] = vos_create_thread(24, SmallTCB, &ForwardReports, 1, 16);
        TCB_Ptr[5] = vos_create_thread(24, StandardTCB, &Record, 1, 32);
        TCB_Ptr[6] = vos_create_thread(28, SmallTCB, &RecordButton, 0);    // Not traced
        TCB_Ptr[7] = vos_create_thread(28, SmallTCB, &PlaybackButton, 0);  // Not traced
        TCB_Ptr[8] = vos_create_thread(29, StandardTCB, &Playback, 1, 64);
        TCB_Ptr[9] = vos_create_thread( 1, StandardTCB, &MyIdleTask, 0);
        TCB_Ptr[10] = vos_create_thread(26, StandardTCB, &FindMouse, 1, 2);
        TCB_Ptr[11] = (vos_tcb_t*) MemCheck(2);

// Start Scheduler to kick off the created thread(s)
        vos_start_scheduler();
        }

// It is an error to get here, use a breakpoint to catch this
    while (1) {
        CheckStatus(1, ErrorSchedulerDidNotStart);
        }
    }

