/*
** Host.c  - support routines for USB Host
**
** Author:  John Hyde, USB Design By Example
*/

#include "main.h"

extern VOS_HANDLE hDevice[NUMBER_OF_DEVICES];
extern vos_mutex_t SearchHostLock;

rom char Dot[] = " .%d";
rom char DeviceInterfacesFound[] = "\n%d Device Interface(s) Found:";
rom char CheckingDeviceInterface[] = "\n\nChecking Device Interface %d";
rom char CouldNotAttach[] = "\nCould not attach to device interface, status = %d";
rom char CouldNotGetClass[] = "\nCould not get class info, status = %d";
rom char ClassInfo[] = "\nClass Info(%d): ";
rom char CouldNotGetEP0[] = "Could not get EP0 (%d) ";
rom char DataEPIs[] = "\nDataEP is %x, %X";
rom char CouldNotGetDataEP[] = "Could not get Data Endpoint (%d) ";
rom char CouldNotGetDataEP_2[] = "Could not get Data Endpoint_2 (%d) ";
rom char WaitingForReports[] = "\nWaiting for reports from %s";
rom char ReadReportError[] = "Read Report Error (%d) ";

usbhost_device_handle* WaitForDevice(BYTE ThreadID, BYTE Class, BYTE Protocol) {
    usbhost_ioctl_cb_t hc_iocb;
    usbhost_device_handle* ifDev, Found;
    usbhost_ioctl_cb_class_t hc_iocb_class;
    BYTE Interface, InterfaceCount;
    BYTE State, Status;
// Return when the requested device has been found
    while (1) {
        i_vos_delay_msecs(ThreadID, 2000);
// VOS didn't like two copies of this routine running concurrently, so sequence them
        vos_lock_mutex(&SearchHostLock);
        Found = 0;
        dprint(&Dot[0], &Protocol);
// Check that the host has finished enumeration
        hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_GET_CONNECT_STATE;
        hc_iocb.get = &State;
        i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
        if (State == PORT_STATE_ENUMERATED) {
// Discover attached device(s)
            hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_GET_COUNT;
            hc_iocb.get = &InterfaceCount;
            i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
            dprint(&DeviceInterfacesFound[0], &InterfaceCount);
            for (Interface=0; Interface<InterfaceCount; Interface++) {
// Get a handle to this device interface
                dprint(&CheckingDeviceInterface[0], &Interface);
                hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_GET_NEXT_HANDLE;
                hc_iocb.handle.dif = Interface ? ifDev : NULL;
                hc_iocb.get = &ifDev;
                Status = i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
                if (Status != USBHOST_OK) {
                    dprint(&CouldNotAttach[0], &Status);
                    break;
                    }
// For education purposes, print out the descriptors for this interface
//                DisplayDescriptors(ThreadID, ifDev);
// Search through the enumerated device(s) the requested device
                memset(&hc_iocb_class, 0, sizeof(&hc_iocb_class));
                hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_GET_CLASS_INFO;
                hc_iocb.handle.dif = ifDev;
                hc_iocb.get = &hc_iocb_class;
                Status = i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
                if (Status == USBHOST_OK) {
                    dprint(&ClassInfo[0], &Protocol);
                    dprintBuffer((BYTE*)&hc_iocb_class, sizeof(hc_iocb_class));
                    if ((hc_iocb_class.dev_class==Class)&&(hc_iocb_class.dev_protocol==Protocol)) Found=ifDev;
                    }
                else dprint(&CouldNotGetClass[0], &Status);
                }
            }
// Finished searching
        vos_unlock_mutex(&SearchHostLock);
        if (Found) return Found;
        }
    return 0; // Keep compiler happy
    }

usbhost_device_handle* WaitForKeyboard(BYTE ThreadID) {
    return WaitForDevice(ThreadID, USB_CLASS_HID, USB_PROTOCOL_HID_KEYBOARD);
    }

usbhost_device_handle* WaitForMouse(BYTE ThreadID) {
    return WaitForDevice(ThreadID, USB_CLASS_HID, USB_PROTOCOL_HID_MOUSE);
    }

BOOL GetReports(BYTE ThreadID, usbhost_device_handle* ifDev, MessageType* Message) {
// This function initializes the identified HID, receives Reports from it and forwards them
// This function owns the ReportBuffer which is long enough to receive keyboard reports
    BYTE ReportBuffer[MaxReportLength];
    usbhost_ep_handle* epData, epCtrl;
    usbhost_ioctl_cb_t hc_iocb;
    usbhost_xfer_t xfer;
    usb_deviceRequest_t Request;
    BYTE Status;
    vos_semaphore_t ReportReceived, Returned;
// Have the device handle, also need handles to EP0 and Data Endpoint
    hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_GET_CONTROL_ENDPOINT_HANDLE;
    hc_iocb.handle.dif = ifDev;
    hc_iocb.get = &epCtrl;
    Status = i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
    if (Status != USBHOST_OK) return dprint(&CouldNotGetEP0[0], &Status);
// Setup HID for Boot Protocol and to only send Reports on a data change
    memset(&Request, 0, sizeof(Request));
    Request.bmRequestType = USB_BMREQUESTTYPE_CLASS | USB_BMREQUESTTYPE_INTERFACE;
    Request.bRequest = USB_HID_REQUEST_CODE_SET_PROTOCOL;
    hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_SETUP_TRANSFER;
    hc_iocb.handle.ep = epCtrl;
    hc_iocb.set = &Request;
    i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
/// hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_SETUP_TRANSFER;
/// Request.bmRequestType = USB_BMREQUESTTYPE_CLASS | USB_BMREQUESTTYPE_INTERFACE;
    Request.bRequest = USB_HID_REQUEST_CODE_SET_IDLE;
/// hc_iocb.handle.ep = epCtrl;
/// hc_iocb.set = &Request;
    i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
// Now get a handle for the Data Endpoint
    hc_iocb.ioctl_code = VOS_IOCTL_USBHOST_DEVICE_GET_INT_IN_ENDPOINT_HANDLE;
    hc_iocb.handle.dif = ifDev;
    hc_iocb.get = &epData;
    Status = i_vos_dev_ioctl(ThreadID, hDevice[Host], &hc_iocb);
    dprint(&DataEPIs[0], epData);
    if (Status != USBHOST_OK) return dprint(&CouldNotGetDataEP[0], &Status);
// Now wait for data reports
    dprint(&WaitingForReports[0], Message->NamePtr);
// VOS uses a semaphore to signal when a report has been received
    vos_init_semaphore(&ReportReceived, 0);
// I also use one to know when I can use the ReportBuffer again
    vos_init_semaphore(&Returned, 0);
// Initialize transfer data, I do the same transfer over and over again
    Message->ReportBuffer = &ReportBuffer[0];
    Message->ResponseSemaphore = &Returned;
    while (1) {
        memset(&xfer, 0, sizeof(usbhost_xfer_t));
        xfer.s = &ReportReceived;
        xfer.ep = epData;
        xfer.buf = Message->ReportBuffer;
        xfer.len = MaxReportLength;
        xfer.flags = USBHOST_XFER_FLAG_ROUNDING;
// Wait for a report to arrive from device
        Status = i_vos_dev_read(ThreadID, hDevice[Host], (BYTE*)&xfer, sizeof(usbhost_xfer_t), NULL);
        if (Status != USBHOST_OK) return dprint(&ReadReportError[0], &Status);
// Send the Report off to be processed
        i_vos_signal_semaphore(ThreadID, Message->SignalSemaphore);
// Need ownership of Message to continue
        i_vos_wait_semaphore(ThreadID, &Returned);
        }
    }

