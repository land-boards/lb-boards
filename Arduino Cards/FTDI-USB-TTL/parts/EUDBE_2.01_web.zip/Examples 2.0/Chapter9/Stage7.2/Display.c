/*
** Display.c  - Displays text and variables
**
** Author:  John Hyde, USB Design By Example
*/

#include "main.h"

extern VOS_HANDLE hDevice[NUMBER_OF_DEVICES];
extern vos_mutex_t dprintLock;

BYTE LocalBuffer[128];
BYTE* BytePtr;
WORD BufferIndex;
WORD ROMIndex;
rom char ASCII[] = "0123456789abcdef";
rom char NewLine[] = "\n";
rom char PerCentx[] = " %x";

void DisplayChar(BYTE Character) {
    if (Character) {
        LocalBuffer[BufferIndex] = Character;
        if (BufferIndex < (sizeof(LocalBuffer)-1)) BufferIndex++;
        }
    }

void DisplayHex(BYTE Value) {
    DisplayChar(ASCII[Value >> 4]);
    DisplayChar(ASCII[Value & 15]);
    }

void DisplayDecimal(WORD Value) {
// Convert Value to Digits for printing
    BYTE Digits[5];        // Maximum is 64K
    BYTE i;
    for (i=0; i<sizeof(Digits); i++) {
        Digits[i] = Value % 10;
        Value = (Value - Digits[i])/10;
        }
// Supress leading 0's.  Note ASCII[16] = 0
    for (i=sizeof(Digits)-1; i>0; i--) {
        if (Digits[i]) break;
        else Digits[i] = 16;
        }
    for (i=sizeof(Digits); i>0; i--) {
        BYTE Temp = Digits[i-1];
        DisplayChar(ASCII[Temp]);
        }
    }

BOOL dprint(rom char ROMBuffer[], void* DataPtr) {
// dprint is modelled after printf but can only take one parameter
// stringptr points to a format string that can include one of the following
// %d - void* points to a byte that is printed in decimal (0..255)
// %D - void* points to a word that is printed in decimal (0..65,535)
// %x - void* points to a byte that is printed in hex (0x00..0xFF)
// %X - void* points to a word that is printed in hex (0x0000..0xFFFF)
// %L - void* points to a double word (Long) that is printed in hex (0x00000000..0xFFFFFFFF)
// %c - void* points to a single ASCII character
// %s - void* points to a 0-terminated string in RAM
// dprint can be called from multiple threads, so use a mutex to keep output from a single dprint() together
    vos_lock_mutex(&dprintLock);
    BytePtr = (BYTE*) DataPtr;
    BufferIndex = 0;
    ROMIndex = 0;
    while (ROMBuffer[ROMIndex]) {
        if (ROMBuffer[ROMIndex] == '%') {
            switch (ROMBuffer[++ROMIndex]) {
                case 'd': DisplayDecimal((WORD)*BytePtr); break;
                case 'D': DisplayDecimal(*(WORD*) DataPtr); break;
                case 'x': DisplayHex(*BytePtr); break;
                case 'X': DisplayHex(*(++BytePtr)); DisplayHex(*(--BytePtr)); break;    // Little endian
                case 'L': BytePtr+=3; DisplayHex(*BytePtr--); DisplayHex(*BytePtr--); DisplayHex(*BytePtr--); DisplayHex(*BytePtr); break;
                case 'c': DisplayChar(*BytePtr); break;
                case 'S':
                case 's': while (*BytePtr) DisplayChar(*BytePtr++); break;
                case '%': DisplayChar('%'); break;
                default:  DisplayChar(ROMBuffer[ROMIndex]); DisplayChar('?'); break;
                }
            ROMIndex++;
            }
        else DisplayChar(ROMBuffer[ROMIndex++]);
        }
    vos_dev_write(hDevice[UART], &LocalBuffer[0], BufferIndex, NULL);
    vos_unlock_mutex(&dprintLock);
    return 0;    // Used to break out of proceedures on errors
    }

void dprintBuffer(BYTE* BufferPtr, int Count) {
    int i;
    for (i=0; i<Count; i++) {
        if ((Count>32) && !(i & 31)) dprint(&NewLine[0], 0);
        dprint(&PerCentx[0], BufferPtr++);
        }
    }


