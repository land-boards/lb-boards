/*
** Support.c module = helper routines for main.c
**
** Author:  John Hyde, USB Design By Example
*/

#include "main.h"

extern VOS_HANDLE hDevice[NUMBER_OF_DEVICES];

BOOL GetElapsedTimeCalled;

rom BYTE SetBinaryPageSize[4] = {0x3d, 0x2a, 0x80, 0xa6};
rom char SendingSPIBytes[] = "\nSending %D bytes to SPI:";
rom char ReceivedSPIBytes[] = "\nReceived %D bytes from SPI:";
rom char WARNINGPageSize[] = "WARNING: Need to power off to reset Atmel DataFlash page size\n";
rom char WARNINGNotConnected[] = "WARNING: DataFlash not connected\n";

void SendAndReceiveSPIBytes(BYTE ThreadID, BYTE* BufferPtr, WORD Length, BOOL Receive) {
    BYTE Status;
    common_ioctl_cb_t iocb;
    iocb.ioctl_code = VOS_IOCTL_SPI_MASTER_SS_0;
    iocb.set.param = SPI_MASTER_SS_ENABLE;
    i_vos_dev_ioctl(ThreadID, hDevice[SPIM], &iocb);     // Drive CS 0
    Status = i_vos_dev_write(ThreadID, hDevice[SPIM], BufferPtr, Length, NULL);
// Un-comment the following dprint lines to see SPI traffic; the display slows operation!
//    dprint(&SendingSPIBytes[0], &Length);
//    dprintBuffer(BufferPtr, (int)Length);
    if (Receive) {
        i_vos_dev_read(ThreadID, hDevice[SPIM], BufferPtr, Length, NULL);
//        dprint (&ReceivedSPIBytes[0], &Length);
//        dprintBuffer(BufferPtr, (int)Length);
        }
    else {
// Read and discard the input bytes. SPI is synchronous so reads must match writes
        BufferPtr = vos_malloc(Length);
        i_vos_dev_read(ThreadID, hDevice[SPIM], BufferPtr, Length, NULL);
        vos_free(BufferPtr);
        }
    iocb.ioctl_code = VOS_IOCTL_SPI_MASTER_SS_0;
    iocb.set.param = SPI_MASTER_SS_DISABLE;
    i_vos_dev_ioctl(ThreadID, hDevice[SPIM], &iocb);
    }

BOOL CheckDataFlash(BYTE ThreadID) {
    BYTE Buffer[4];
    BYTE i;
// First check that the DataFlash is connected
    memset(&Buffer[0], 0xFF, sizeof(Buffer));
    Buffer[0] = AtmelGetDeviceID;
    SendAndReceiveSPIBytes(ThreadID, &Buffer[0], sizeof(Buffer), TRUE);
    if ((Buffer[1] != 0x1F) || (Buffer[2] != 0x26)) return dprint(&WARNINGNotConnected[0], 0);
// Now check that the DataFlash is set to binary page size
    memset(&Buffer[0], 0xFF, sizeof(Buffer));
    Buffer[0] = AtmelGetStatus;
    SendAndReceiveSPIBytes(ThreadID, &Buffer[0], sizeof(Buffer), TRUE);
    if (Buffer[2] & 1) return 1;
// Need to change Page Size
    for (i=0; i<sizeof(Buffer); i++) Buffer[i] = SetBinaryPageSize[i];
    SendAndReceiveSPIBytes(ThreadID, &Buffer[0], sizeof(Buffer), FALSE);
    return dprint(&WARNINGPageSize[0], 0);
    }

WORD GetElapsedTime(void) {
// return 100 the first time that this is called, else return ElapsedTime
    tmr_ioctl_cb_t tmr_iocb;
    WORD CurrentCount;
    BYTE Status = 0;
    tmr_iocb.ioctl_code = VOS_IOCTL_TIMER_STOP;
    Status |= vos_dev_ioctl(hDevice[Timer0], &tmr_iocb);
    tmr_iocb.ioctl_code = VOS_IOCTL_TIMER_GET_CURRENT_COUNT;
    Status |= vos_dev_ioctl(hDevice[Timer0], &tmr_iocb);
    CurrentCount = tmr_iocb.param;
    tmr_iocb.ioctl_code = VOS_IOCTL_TIMER_START;
    Status |= vos_dev_ioctl(hDevice[Timer0], &tmr_iocb);
    CheckStatus(Status, ErrorTimer0);
    if (GetElapsedTimeCalled) return CurrentCount;
    GetElapsedTimeCalled = TRUE;
    return 100;
    }

WORD Swap(WORD w) {
// Here is an example of an assembler routine called from C
    asm {
        SP_STORE %eax            # Get current SP
        ADD16 %eax $5            # Point eax to 16-bit parameter
        SP_STORE %ebx            # Get current SP
        ADD16 %ebx $3            # Point ebx to 16-bit return value
        ROR16 (%ebx) (%eax) $8   # Swap bytes
        RTS
        }
    return 1;     // Keep compiler happy
    }

