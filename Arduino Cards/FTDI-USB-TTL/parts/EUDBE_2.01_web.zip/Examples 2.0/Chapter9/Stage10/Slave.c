/*
** Slave.c module for Chapter9 Example
**
** Author:  John Hyde, USB Design By Example
*/

#include "main.h"

extern VOS_HANDLE hDevice[NUMBER_OF_DEVICES];
extern vos_semaphore_t EnumerationComplete;

rom char InSendResponse[] = "\nIn SendResponse with %X buffer: ";
rom char ACKSent[] = "\nACK Sent";
rom char InHandleChapter9Request[] = "\nIn HandleChapter9Request with %x";
rom char AtSetAddress[] = "\nAt SetAddress with %X";
rom char InGetDescriptor[] = "\nIn Get Descriptor with %x";
rom char GetDeviceDescriptor[] = "\nGet Device Descriptor (%X)";
rom char GetConfigurationDescriptor[] = "\nGet Configuration Descriptor (%X)";
rom char GetString[] = "\nGet String (%x)";
rom char GetConfiguration[] = "\nGet Configuration = %x";
rom char GetStatus[] = "\nGet Status(%d)";
rom char SetConfiguration[] = "\nSet Configuration = %x";
rom char InHandleHIDClassRequest[] = "\nIn HandleHIDClassRequest with %x";
rom char InSetReport[] = "\nIn SetReport with length = %X";
rom char KeyboardLEDsSet[] = "\nKeyboard LEDs set to %x";

// My slave has EP0 plus EP1_In and EP2_In
usbslave_ep_handle_t EP0_In, EP0_Out, EP1_In, EP2_In;
BYTE Configuration;
BYTE KeyboardLEDs;

// Declare my descriptors - this is used for the 'real' keyboard and the 'user' keyboard
BYTE KeyboardReportDescriptor[] = {
    5, 1,        //  Usage_Page (Generic Desktop)
    9, 6,        //  Usage (Keyboard)
    0xA1, 1,     //  Collection (Application)
// First declare the key usage input report
    5, 7,        //    Usage page (KeyBoard)
    0x19, 0xE0,  //    Usage_Minimum (Keyboard - Left Control)
    0x29, 0xE7,  //    Usage_Maximum (Keyboard - Right GUI)
    0x15, 0,     //    Logical_Minimum (0)
    0x25, 1,     //    Logical_Maximum (1)
    0x75, 1,     //    Report_Size (1)
    0x95, 8,     //    Report_Count (8)
    0x81, 2,     //    Input (Data,Var,Abs) = Modifier Byte
    0x81, 1,     //    Input (Constant) = Reserved Byte
    0x19, 0,     //    Usage_Minimum (Keyboard - 0)
    0x29, 82,    //    Usage_Maximum (Keyboard - UpArrow)
    0x15, 0,     //    Logical_Minimum (0)
    0x25, 82,    //    Logical_Maximum (82)
    0x75, 8,     //    Report_Size (8)
    0x95, 6,     //    Report_Count (KeycodesMax)
    0x81, 0,     //    Input (Data,Array) = Key Usage Bytes
// Now the LED output report
    5, 8,        //    Usage Page (LEDs)
    0x19, 1,     //    Usage_Minimum (LED - Num Lock)
    0x29, 5,     //    Usage_Maximum (LED - Kana)
    0x15, 0,     //    Logical_Minimum (0)
    0x25, 1,     //    Logical_Maximum (1)
    0x75, 1,     //    Report_Size (1)
    0x95, 5,     //    Report_Count (5)
    0x91, 2,     //    Output (Data,Var,Abs) = LEDs (5 bits)
    0x95, 3,     //    Report_Count (3)
    0x91, 1,     //    Output (Constant) = Pad (3 bits)
    0xC0         //  End_Collection
    };
BYTE UserKeyboardReportDescriptor[] = {
// Describe the same byte pattern but not in a format that Windows will recognize
// Define an 'array of 8 bytes' for input and optionally 1 byte for output
    6, 0, 0xFF,  //  Usage_Page (Vendor Defined)
    9, 1,        //  Usage (I/O Device)
    0xA1, 1,     //  Collection (Application)
    0x19, 1,     //    Usage_Minimum (1)
    0x29, 2,     //    Usage_Maximum (2)
    0x15, 0x80,  //    Logical_Minimum (-128)
    0x25, 0x7F,  //    Logical_Maximum (+127)
    0x75, 8,     //    Report_Size (8)
    0x95, 8,     //    Report_Count (8)
    0x81, 0,     //    Input (Data,Array,Abs) = 8 Bytes
// Include an LED output report if needed
//    0x19, 1,     //    Usage_Minimum (1)
//    0x29, 2,     //    Usage_Maximum (2)
//    0x95, 1,     //    Report_Count (1)
//    0x91, 0,     //    Output (Data,Var,Abs) = 1 Byte
    0xC0         //  End_Collection
    };
BYTE MyDeviceDescriptor[] = {
    18, 1, 0x10, 1, 0, 0, 0, 8, 0x42, 0x42, 0x25, 3, 0x30, 0, 1, 2, 3, 1 };
BYTE MyConfigurationDescriptor[] = {
// Configuration Header
    9, 2, 59, 0, 2, 1, 0, 0x80, 50,
// Interface 0 = Keyboard
    9, 4, 0, 0, 1, 3, 1, 1, 0,
// HID Class
    9, 0x21, 0x10, 1, 0, 1, 0x22, sizeof(KeyboardReportDescriptor), 0,
// Endpoint, EP1_In
    7, 5, 0x81, 3, 8, 0, 10,
// Interface 1 = 'User' Keyboard
    9, 4, 1, 0, 1, 3, 0, 0, 0,        // Note subclass = protocol = 0, a 'generic' HID
// HID Class
    9, 0x21, 0x10, 1, 0, 1, 0x22, sizeof(UserKeyboardReportDescriptor), 0,
// Endpoint, EP2_In
    7, 5, 0x82, 3, 8, 0, 10
    };
BYTE String0[] = { 4, 3, 9, 4 };    // Only English language strings supported
BYTE String1[] = {44, 3, 'U',0,'S',0,'B',0,' ',0,'D',0,'e',0,'s',0,'i',0,'g',0,'n',0,' ',0,
                           'B',0,'y',0,' ',0,'E',0,'x',0,'a',0,'m',0,'p',0,'l',0,'e',0 };
BYTE String2[] = {26, 3, 'D',0,'u',0,'a',0,'l',0,'K',0,'e',0,'y',0,'b',0,'o',0,'a',0,'r',0,'d',0 };
BYTE String3[] = {26, 3, '6',0,'0',0,'0',0,'D',0,'1',0,'D',0,'E',0,'A',0,'0',0,'0',0,'4',0,'6',0 };

BYTE SendStall(BYTE ThreadID, BYTE Endpoint) {
    usbslave_ioctl_cb_t iocb;
    iocb.ioctl_code = VOS_IOCTL_USBSLAVE_ENDPOINT_STALL;
    iocb.ep = Endpoint;
    i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
    return 1;
    }

BYTE SendResponse(BYTE ThreadID, void* BufferPtr, WORD RequestedLength, WORD ActualLength) {
    usbslave_ioctl_cb_t iocb;
    iocb.ioctl_code = VOS_IOCTL_USBSLAVE_SETUP_TRANSFER;
    iocb.handle = EP0_In;
    iocb.request.setup_or_bulk_transfer.buffer = BufferPtr;
    iocb.request.setup_or_bulk_transfer.size = RequestedLength>ActualLength ? ActualLength : RequestedLength;
    dprint(&InSendResponse[0], &BufferPtr);
    dprintBuffer(BufferPtr, iocb.request.setup_or_bulk_transfer.size);
    i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
    return 0;
    }

BYTE SendACK(BYTE ThreadID) {
    usbslave_ioctl_cb_t iocb;
    iocb.ioctl_code = VOS_IOCTL_USBSLAVE_SETUP_TRANSFER;
    iocb.handle = EP0_In;
    iocb.request.setup_or_bulk_transfer.buffer = (void*) 0;
    iocb.request.setup_or_bulk_transfer.size = 0;
    i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
    return dprint(&ACKSent[0], 0);
    }

BYTE HandleChapter9Request(BYTE ThreadID, SetupPacket* Setup) {
    BYTE Temp;
    WORD Status;
    usbslave_ioctl_cb_t iocb;
    dprint(&InHandleChapter9Request[0], &Setup->bRequest);
    switch (Setup->bRequest) {
        case USB_REQUEST_CODE_SET_ADDRESS:
            dprint(&AtSetAddress[0], &Setup->wValueLo);
            iocb.ioctl_code = VOS_IOCTL_USBSLAVE_SET_ADDRESS;
            iocb.set = (void*) Setup->wValueLo;
            i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
            return SendACK(ThreadID);
        case USB_REQUEST_CODE_GET_DESCRIPTOR:
            dprint(&InGetDescriptor[0], &Setup->wValueHi);
            switch (Setup->wValueHi) {
                case USB_DESCRIPTOR_TYPE_DEVICE:
                    dprint(&GetDeviceDescriptor[0], &Setup->wValueHi);
                    return SendResponse(ThreadID, &MyDeviceDescriptor[0], Setup->wLength, MyDeviceDescriptor[0]);
                case USB_DESCRIPTOR_TYPE_CONFIGURATION:
                    dprint(&GetConfigurationDescriptor[0], &Setup->wLength);
// Use LSB of TotalLength - OK if TotalLength<0x100
                    return SendResponse(ThreadID, &MyConfigurationDescriptor[0], Setup->wLength, MyConfigurationDescriptor[2]);
                case USB_DESCRIPTOR_TYPE_STRING:
                    dprint(&GetString[0], &Setup->wValueLo);
                    switch (Setup->wValueLo) {
                        case 0: return SendResponse(ThreadID, &String0[0], Setup->wLength, String0[0]);
                        case 1: return SendResponse(ThreadID, &String1[0], Setup->wLength, String1[0]);
                        case 2: return SendResponse(ThreadID, &String2[0], Setup->wLength, String2[0]);
                        case 3: return SendResponse(ThreadID, &String3[0], Setup->wLength, String3[0]);
                        default: break;
                        }
                    break;
                case 0x22:    // This is request for the HID Report Descriptor
                    if (Setup->wIndexLo == 0) return SendResponse(ThreadID, &KeyboardReportDescriptor[0], Setup->wLength, sizeof(KeyboardReportDescriptor));
                    if (Setup->wIndexLo == 1) return SendResponse(ThreadID, &UserKeyboardReportDescriptor[0], Setup->wLength, sizeof(UserKeyboardReportDescriptor));
                    break;
// Since I declared myself as USB 1.1 I should not get these requests, respond with a STALL
                case USB_DESCRIPTOR_TYPE_ENDPOINT:
                case USB_DESCRIPTOR_TYPE_DEVICE_QUALIFIER:
                case USB_DESCRIPTOR_TYPE_OTHER_SPEED_CONFIGURATION:
                    break;
                }
            break;
        case USB_REQUEST_CODE_SET_CONFIGURATION:
            dprint(&SetConfiguration[0], &Setup->wValueLo);
            vos_signal_semaphore(&EnumerationComplete);
            return SendACK(ThreadID);
        case USB_REQUEST_CODE_GET_CONFIGURATION:
            dprint(&GetConfiguration[0], &Configuration);
            return SendResponse(ThreadID, &Configuration, Setup->wLength, 1);
        case USB_REQUEST_CODE_GET_STATUS:
            Temp = Setup->bmRequestType & 3;
            dprint(&GetStatus[0], &Temp);
// 0=Device: Bit 1 = RemoteWakeup = 0; Bit 0 = SelfPowered = 0
// 1=Interface, defined as = 0
// 2=Endpoint, Bit 1 = 1 if endpoint is halted
            Status = 0;
            if (Temp == 2) {
                iocb.ioctl_code = VOS_IOCTL_USBSLAVE_ENDPOINT_STATE;
                iocb.ep = Setup->wIndexLo;
                iocb.get = &Temp;
                i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
                if (Temp) Status = 1;
                }
            return SendResponse(ThreadID, &Status, Setup->wLength, 2);
        case USB_REQUEST_CODE_CLEAR_FEATURE:
// The only ClearFeature I support is an Endpoint halt
            if (((Setup->bmRequestType & 3) == 2) && (Setup->wValueLo == 0)) {
                iocb.ioctl_code = VOS_IOCTL_USBSLAVE_ENDPOINT_CLEAR;
                iocb.set = (void*) Setup->wIndexLo;
                i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
                return SendACK(ThreadID);
                }
            break;
        case USB_REQUEST_CODE_SET_FEATURE:
// The only SetFeature I support is an Endpoint halt
            if (((Setup->bmRequestType & 3) == 2) && (Setup->wValueLo == 0)) {
                iocb.ioctl_code = VOS_IOCTL_USBSLAVE_ENDPOINT_STALL;
                iocb.set = (void*) Setup->wIndexLo;
                i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
                return SendACK(ThreadID);
                }
            break;

        case USB_REQUEST_CODE_GET_INTERFACE:
        case USB_REQUEST_CODE_SET_INTERFACE:
// How do I issue a Get/Set Interface?  Do I need to close and then reopen handles?

// I don't support the following requests, return a STALL
        case USB_REQUEST_CODE_SET_DESCRIPTOR:
        case USB_REQUEST_CODE_SYNCH_FRAME:
            break;
        }
    return SendStall(ThreadID, 0);
    }

BYTE HandleHIDClassRequest(BYTE ThreadID, usb_deviceRequest_t* Setup) {
    usbslave_ioctl_cb_t iocb;
    BYTE Zero = 0;
    dprint(&InHandleHIDClassRequest[0], &Setup->bRequest);
    switch (Setup->bRequest) {
        case USB_HID_REQUEST_CODE_SET_REPORT:
// The host is wanting the set the Keyboard LEDs
            dprint(&InSetReport[0], &Setup->wLength);
            iocb.ioctl_code = VOS_IOCTL_USBSLAVE_SETUP_TRANSFER;
            iocb.handle = EP0_Out;
            iocb.request.setup_or_bulk_transfer.buffer = &KeyboardLEDs;
            iocb.request.setup_or_bulk_transfer.size = Setup->wLength;
            iocb.request.setup_or_bulk_transfer.bytes_transferred = 0;
            i_vos_dev_ioctl(ThreadID, hDevice[Slave], &iocb);
            SendACK(ThreadID);
            return dprint(&KeyboardLEDsSet[0], &KeyboardLEDs);
        case USB_HID_REQUEST_CODE_SET_IDLE:
// I only support infinite, so just ACK this
        case USB_HID_REQUEST_CODE_SET_PROTOCOL:
// I only support boot protocol, so just ACK this
            return SendACK(ThreadID);
// Return a single byte 0; IDLE = infinite, Protocol = boot
        case USB_HID_REQUEST_CODE_GET_IDLE:
        case USB_HID_REQUEST_CODE_GET_PROTOCOL:
            return SendResponse(ThreadID, &Zero, Setup->wLength, 1);
        }
// I STALL all other requests
    return SendStall(ThreadID, 0);
    }

BYTE HandleRequest(BYTE ThreadID, usb_deviceRequest_t* Setup) {
    BYTE Temp;
    Temp = Setup->bmRequestType & 0x60;
    if (Temp == USB_BMREQUESTTYPE_STANDARD) return HandleChapter9Request(ThreadID, Setup);
    if (Temp == USB_BMREQUESTTYPE_CLASS) return HandleHIDClassRequest(ThreadID, Setup);
    return SendStall(ThreadID, 0);
    }

