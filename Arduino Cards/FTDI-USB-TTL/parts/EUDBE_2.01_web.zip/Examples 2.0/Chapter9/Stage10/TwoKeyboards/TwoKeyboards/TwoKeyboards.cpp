// TwoKeyboards.cpp : Defines the entry point for the console application.
//
//  (c) 2010 John Hyde, USB Design By Example

#include "stdafx.h"

extern "C" {
// Declare the C libraries used
#include <objbase.h>
#include <windows.h>
#include <conio.h>
#include <stdlib.h>
#include "setupapi.h"		// Must link in setupapi.lib
#include "hidsdi.h"			// Must link in hid.lib
	}

HANDLE	PnPHandle, HIDHandle, Event;
char NextChar;
OVERLAPPED Overlapped;
struct	_GUID HID_GUID;
const char Spin[] = {"|/-\\"};
char DisplayBuffer[81];		// Windows keyboard displayed in 0-39, User keyboard displayed in 40-79
int WindowsIndex, UserIndex;

//                                    1234567890123456789012345678901234567890 123 456789 01234567
const char HidUsageToASCIITable1[] = "????abcdefghijklmnopqrstuvwxyz1234567890\r??\t -=[]\\?;'',./";
const char HidUsageToASCIITable2[] = "????ABCDEFGHIJKLMNOPQRSTUVWXYZ!@#$%^&*()\r??\t _+{}|?:\"~<>?";

int Error(char* TextPtr) {
// Let the system decode my error codes
    char errorBuffer[80];
    DWORD count, ErrorCode;
	printf("\nERROR: %s. ", TextPtr);
	ErrorCode = GetLastError();
    count = FormatMessage(FORMAT_MESSAGE_FROM_SYSTEM, NULL, ErrorCode, 0, errorBuffer, sizeof(errorBuffer), NULL);
    if (count) return printf("%s\n", errorBuffer);
    else return printf(". Error = %d\n", ErrorCode);
    }

void ClearOverlapped(void) {
	Overlapped.Offset = 0;
	Overlapped.OffsetHigh = 0;
	Overlapped.hEvent = 0;
	}

HANDLE FindHIDInterface(USHORT VID, USHORT PID, USHORT UsagePage) {
	HANDLE	HIDHandle;
	SP_INTERFACE_DEVICE_DATA DeviceInterfaceData;
	struct {DWORD cbSize; char DevicePath[256];} FunctionClassDeviceData;
	HIDD_ATTRIBUTES HIDAttributes;
	PHIDP_PREPARSED_DATA PreparsedDataPtr;
	_HIDP_CAPS Capabilities;
	SECURITY_ATTRIBUTES SA;
	DWORD BytesReturned;
	int Device = 0;
	LONG Success = 1;

	SA.nLength = sizeof(SECURITY_ATTRIBUTES); 
	SA.lpSecurityDescriptor = NULL; 
	SA.bInheritHandle = false; 

	while (Success) {
//		printf("\nDevice = %d", Device);
// Initialize our data
		DeviceInterfaceData.cbSize = sizeof(DeviceInterfaceData);
// Is there a device at this table entry
		Success = SetupDiEnumDeviceInterfaces(PnPHandle, NULL, &HID_GUID, Device++, &DeviceInterfaceData);
		if (Success) {
// There is a device here, get its name
			FunctionClassDeviceData.cbSize = 5;
			Success = SetupDiGetDeviceInterfaceDetail(PnPHandle, &DeviceInterfaceData, 
				(PSP_INTERFACE_DEVICE_DETAIL_DATA)&FunctionClassDeviceData, 256, &BytesReturned, NULL);
			if (Success) {
// Open this device for inspection
//				printf(", Path=%s ", FunctionClassDeviceData.DevicePath);
				HIDHandle = CreateFile(FunctionClassDeviceData.DevicePath, 0, 0, 0, OPEN_EXISTING, 0, NULL);
//				printf(", Handle=%x ", HIDHandle);
//				if (HIDHandle == INVALID_HANDLE_VALUE) printf(", Error=%d", GetLastError());
				if (HIDHandle != INVALID_HANDLE_VALUE) {
// Get information about this HID
					HIDAttributes.Size = sizeof(HIDAttributes);
					Success = HidD_GetAttributes(HIDHandle, &HIDAttributes);
					if (Success) {
// Is it the correct device?
//						printf(", VID = %x, PID = %x", HIDAttributes.VendorID, HIDAttributes.ProductID);
						if ((HIDAttributes.VendorID == VID) && (HIDAttributes.ProductID == PID)) {
// Need the correct interface, check UsagePage
							printf("\nFound device, checking interface\n");
							Success = HidD_GetPreparsedData(HIDHandle, &PreparsedDataPtr);
							if (Success) {
								Success = HidP_GetCaps(PreparsedDataPtr, &Capabilities);
//								printf(", UsagePage = %x", Capabilities.UsagePage);
								if (Success && (Capabilities.UsagePage == UsagePage)) {
									HidD_FreePreparsedData(PreparsedDataPtr);
									CloseHandle(HIDHandle);
// Reopen handle for overlapped operations
									HIDHandle = CreateFile(FunctionClassDeviceData.DevicePath, GENERIC_READ|GENERIC_WRITE, 
										FILE_SHARE_READ|FILE_SHARE_WRITE, &SA, OPEN_EXISTING, FILE_FLAG_OVERLAPPED, NULL);
									return HIDHandle;
									}
								else {
									HidD_FreePreparsedData(PreparsedDataPtr);
									CloseHandle(HIDHandle);
									printf("Could not get Preparsed Data\n");
									}
								}
							}
						}
					}
				}
			}
		}
	return INVALID_HANDLE_VALUE;
	}


HANDLE OpenUSBDevice(USHORT VID, USHORT PID, USHORT UsagePage) {
	HANDLE HIDHandle;
// Initialize the GUID array for a HID
	HidD_GetHidGuid(&HID_GUID);
// Get a handle for the Plug and Play node and request currently active devices
	PnPHandle = SetupDiGetClassDevs(&HID_GUID, NULL, NULL, DIGCF_PRESENT|DIGCF_INTERFACEDEVICE);
	if (PnPHandle == INVALID_HANDLE_VALUE) return INVALID_HANDLE_VALUE;
	HIDHandle = FindHIDInterface(VID, PID, UsagePage);
	SetupDiDestroyDeviceInfoList(PnPHandle);
	return HIDHandle;
	}

BOOL Userkbhit(void) {
// Check if a report has been received
	DWORD BytesRead, ErrorCode;
	BYTE ReportBuffer[9];	// ReportBuffer[0] = ReportID, ReportBuffer[1]..[8] = Report from HID
	BYTE Modifier, Code;
	BOOL Success;
	BOOL GotChar = FALSE;
// Need to use Overlapped IO so that the ReadFile does not block
	ClearOverlapped();
	Success = ReadFile(HIDHandle, &ReportBuffer[0], sizeof(ReportBuffer), &BytesRead, &Overlapped);
	if (Success) {
		Modifier = ReportBuffer[1];
		Code = ReportBuffer[3];
		if (Code) {		// Ignore KeyUp
			GotChar = TRUE;
// Translate from HID UsageCode to ASCII
			if (Code<sizeof(HidUsageToASCIITable1)) {
				NextChar = (Modifier & 0x22) ? HidUsageToASCIITable2[Code] : HidUsageToASCIITable1[Code];
				}
			else NextChar = '?';
			}
		}
// No more reports waiting, check why
	ErrorCode = GetLastError();
	if (ErrorCode == ERROR_IO_PENDING) CancelIo(HIDHandle);
	else {
		if (ErrorCode == 1167) return FALSE;	// Disconnected
		Error("Overlapped Read Report");
		return FALSE;
		}
	return GotChar;
	}

void Display(int ID, char Char) {
// I do no character processing (KISS), this could be added
	switch (ID) {
		case 0:	// Windows keyboard
			DisplayBuffer[WindowsIndex] = Char;
			if (WindowsIndex<39) WindowsIndex++;
			break;
		case 1:	// User keyboard (1)
			DisplayBuffer[40+UserIndex] = Char;
			if (UserIndex<39) UserIndex++;
			break;
		}
	printf("%s\r", &DisplayBuffer[0]);
	}

int main(int argc, char* argv[]) {
	int i = 0;
	printf("Two Keyboards V0.3\n");
// Find the 'User Keyboard' device
	printf("\nWaiting for keyboards ");
	HIDHandle = INVALID_HANDLE_VALUE;
	while (HIDHandle == INVALID_HANDLE_VALUE) {
		Sleep(100);
		HIDHandle = OpenUSBDevice(0x4242, 0x0325, 0xFF00);
		printf("%c\b", Spin[i]);
		if (++i == (sizeof(Spin)-1)) i = 0;
		}
	printf("\nKeyboards found\n");
// Initialize display
	memset(&DisplayBuffer[0], ' ', sizeof(DisplayBuffer)-1);
	DisplayBuffer[80] = 0;
	WindowsIndex = 0;
	UserIndex = 0;

// Now run the main loop forever (or a Windows Control+C)
	while (1) {
// Check the Windows keyboard
		if (_kbhit()) Display(0, _getch());
// Check the User keyboard
		if (Userkbhit()) Display(1, NextChar);
		}

	CloseHandle(HIDHandle);
	return 0;
	}

