/*
** DecodeDescriptor.c  - Do a first pass translation of the descriptor
**
** Author:  John Hyde, USB Design By Example
*/

#include "main.h"

rom char DeviceIs[] = " = Device";
rom char ConfigurationIs[] = " = Configuration";
rom char StringIs[] = " = String Descriptor = '";
rom char PerCentc[] = "%c";
rom char Quote[] = "'";
rom char InterfaceClass[] = " = Interface, Class = ";
rom char NotDefined[] = "Not Defined";
rom char Audio[] = "Audio";
rom char CDCControl[] = "CDC Control";
rom char HID[] = "HID";
rom char Physical[] = "Physical";
rom char StillImage[] = "Still Image";
rom char Printer[] = "Printer";
rom char MassStorage[] = "Mass Storage (BOMS)";
rom char Hub[] = "Hub";
rom char CDCData[] = "CDC Data";
rom char SmartCard[] = "Smart Card";
rom char ContentSecurity[] = "Content Security";
rom char Video[] = "Video";
rom char PersonalHealthcare[] = "Personal Healthcare";
rom char DiagnosticDevice[] = "Diagnostic Device";
rom char WirelessController[] = "Wireless Controller";
rom char Miscellaneous[] = "Miscellaneous";
rom char Application[] = "Application";
rom char VendorDefined[] = "Vendor Defined";
rom char Invalid[] = "Invalid";
rom char Endpoint[] = " = Endpoint";
rom char DeviceQualifier[] = "Device Qualifier";
rom char OtherSpeedConfiguration[] = "Other Speed Configuration";
rom char InterfacePower[] = "Interface Power";
rom char ClassSpecific[] = " = Class Specific";
rom char Unknown[] = "Unknown";
rom char NewLine[] = "\n";

void DecodeDescriptor(BYTE* DescriptorPtr) {
// Feel free to expand this (and send me the result so that I can redistribute it)
    BYTE i;
    BYTE Length = *DescriptorPtr++;
    switch (*DescriptorPtr) {
        case USB_DESCRIPTOR_TYPE_DEVICE:
            dprint(&DeviceIs[0], 0);
            break;
        case USB_DESCRIPTOR_TYPE_CONFIGURATION:
            dprint(&ConfigurationIs[0], 0);
            break;
        case USB_DESCRIPTOR_TYPE_STRING:
            dprint(&StringIs[0], 0);
            for (i = 2; i<Length; i+=2, DescriptorPtr+=2) dprint(&PerCentc[0], *DescriptorPtr);
            dprint(&Quote[0], 0);
            break;
        case USB_DESCRIPTOR_TYPE_INTERFACE:
            dprint(&InterfaceClass[0], 0);
            DescriptorPtr +=4;
            switch (*DescriptorPtr) {
                case 0: dprint(&NotDefined[0], 0); break;
                case USB_CLASS_AUDIO: dprint(&Audio[0], 0); break;
                case USB_CLASS_CDC_CONTROL: dprint(&CDCControl[0], 0); break;
                case USB_CLASS_HID: dprint(&HID[0], 0); break;
                case USB_CLASS_PHYSICAL: dprint(&Physical[0], 0); break;
                case USB_CLASS_IMAGE: dprint(&StillImage[0], 0); break;
                case USB_CLASS_PRINTER: dprint(&Printer[0], 0); break;
                case USB_CLASS_MASS_STORAGE: dprint(&MassStorage[0], 0); break;
                case USB_CLASS_HUB: dprint(&Hub[0], 0); break;
                case USB_CLASS_CDC_DATA: dprint(&CDCData[0], 0); break;
                case USB_CLASS_SMART_CARD: dprint(&SmartCard[0], 0); break;
                case USB_CLASS_CONTENT_SECURITY: dprint(&ContentSecurity[0], 0); break;
                case USB_CLASS_VIDEO: dprint(&Video[0], 0); break;
                case USB_CLASS_PERSONAL_HEALTHCARE: dprint(&PersonalHealthcare[0], 0); break;
                case USB_CLASS_DIAGNOSTIC_DEVICE: dprint(&DiagnosticDevice[0], 0); break;
                case USB_CLASS_WIRELESS_CONTROLLER: dprint(&WirelessController[0], 0); break;
                case USB_CLASS_MISCELLANEOUS: dprint(&Miscellaneous[0], 0); break;
                case USB_CLASS_APPLICATION: dprint(&Application[0], 0); break;
                case USB_CLASS_VENDOR: dprint(&VendorDefined[0], 0); break;
                default: dprint(&Invalid[0], 0);
                }
            break;
        case USB_DESCRIPTOR_TYPE_ENDPOINT: dprint(&Endpoint[0], 0); break;
        case USB_DESCRIPTOR_TYPE_DEVICE_QUALIFIER: dprint(&DeviceQualifier[0], 0); break;
        case USB_DESCRIPTOR_TYPE_OTHER_SPEED_CONFIGURATION: dprint(&OtherSpeedConfiguration[0], 0); break;
        case USB_DESCRIPTOR_TYPE_INTERFACE_POWER: dprint(&InterfacePower[0], 0); break;
        case 0x21:
        case 0x22:
        case 0x23:
        case 0x24:
        case 0x25: dprint(&ClassSpecific[0], 0); break;
        default: dprint(&Unknown[0], 0);
        }
    dprint(&NewLine[0], 0);
    }


