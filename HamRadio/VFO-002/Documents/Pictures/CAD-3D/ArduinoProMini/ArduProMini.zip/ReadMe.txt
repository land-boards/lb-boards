These files for KiCad provide two components/footprints...

ArduProMini

ArduProMini-6

The latter is merely the former MINUS the SIX (hence "-6")
   pins/pads at the end of the Arduino Pro Mini which are
   used to connect to the programming cable.

I suspect for most people using the .lib and .mod, the
   -6 variant will be the most useful.

I make no promises about the electrical types assigned to
   the pins... there may be earrors there which will
   interfere with using eeSchema's ERC tool... sorry.
   But the components and modules should "work" in other
   respects, and be useful to you in your KiCad/Arduino
   life!

More at...

http://kicadhowto.org/  (KiCad)

... and ...

http://sheepdogguides.com/arduino/artut.htm (Arduino)

Hope these are useful. Tom Boyd, 11 Feb 15